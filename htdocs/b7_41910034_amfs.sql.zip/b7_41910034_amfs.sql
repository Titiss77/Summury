-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Hôte : sql307.byethost7.com
-- Généré le :  ven. 28 août 2026 à 16:28
-- Version du serveur :  11.4.12-MariaDB
-- Version de PHP :  7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `b7_41910034_amfs`
--

-- --------------------------------------------------------

--
-- Structure de la table `audit_logs`
--

CREATE TABLE `audit_logs` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED DEFAULT NULL,
  `action` varchar(100) NOT NULL,
  `details` text DEFAULT NULL,
  `ip_address` varchar(45) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `audit_logs`
--

INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `details`, `ip_address`, `created_at`) VALUES
(1, 2, 'Mise à jour Carte', 'Modification de la carte ID 35 (\'Classroom of the Elite\'). Visibilité : Privée.', '5.49.246.18', '2026-08-19 18:21:03'),
(2, 2, 'Mise à jour Carte', 'Modification de la carte ID 57 (\'Mushoku Tensei\'). Visibilité : Privée.', '5.49.246.18', '2026-08-19 18:21:10'),
(3, 2, 'Mise à jour Carte', 'Modification de la carte ID 55 (\'BLACK TORCH\'). Visibilité : Privée.', '5.49.246.18', '2026-08-19 18:21:18'),
(4, 2, 'Mise à jour Carte', 'Modification de la carte ID 34 (\'Yuru no Tsugai\'). Visibilité : Privée.', '5.49.246.18', '2026-08-19 18:21:26'),
(5, 2, 'Mise à jour Carte', 'Modification de la carte ID 8 (\'Bleach\'). Visibilité : Privée.', '5.49.246.18', '2026-08-19 18:21:42'),
(6, 2, 'Mise à jour Carte', 'Modification de la carte ID 24 (\'Noble Reincarnation\'). Visibilité : Privée.', '5.49.246.18', '2026-08-19 18:21:49'),
(7, 2, 'Mise à jour Carte', 'Modification de la carte ID 5 (\'Frieren\'). Visibilité : Privée.', '5.49.246.18', '2026-08-19 18:22:02'),
(8, 2, 'Mise à jour Carte', 'Modification de la carte ID 68 (\'Arifureta\'). Visibilité : Privée.', '5.49.246.18', '2026-08-19 18:22:08'),
(9, 2, 'Mise à jour Carte', 'Modification de la carte ID 1 (\'One Piece\'). Visibilité : Privée.', '5.49.246.18', '2026-08-19 18:22:15'),
(10, 2, 'Mise à jour Carte', 'Modification de la carte ID 7 (\'To Your Eternity\'). Visibilité : Privée.', '5.49.246.18', '2026-08-19 18:22:28'),
(11, 2, 'Mise à jour Carte', 'Modification de la carte ID 70 (\'Villainess Level 99\'). Visibilité : Privée.', '5.49.246.18', '2026-08-19 18:22:41'),
(12, 2, 'Mise à jour Carte', 'Modification de la carte ID 71 (\'Goblin Slayer\'). Visibilité : Privée.', '5.49.246.18', '2026-08-19 18:22:48'),
(13, 2, 'Mise à jour Carte', 'Modification de la carte ID 37 (\'Dr. STONE\'). Visibilité : Privée.', '5.49.246.18', '2026-08-19 18:22:55'),
(14, 2, 'Mise à jour Carte', 'Modification de la carte ID 36 (\'Re:ZERO\'). Visibilité : Privée.', '5.49.246.18', '2026-08-19 18:23:03'),
(15, 2, 'Mise à jour Carte', 'Modification de la carte ID 43 (\'Les Carnets de l\'apothicaire\'). Visibilité : Privée.', '5.49.246.18', '2026-08-19 18:23:13'),
(16, 2, 'Mise à jour Carte', 'Modification de la carte ID 79 (\'Oppenheimer\'). Visibilité : Privée.', '5.49.246.18', '2026-08-19 18:23:45'),
(17, 2, 'Reorganisation', 'L\'utilisateur a modifié l\'ordre d\'affichage de 13 carte(s).', '5.49.246.18', '2026-08-19 18:23:49'),
(18, 2, 'Mise à jour Carte', 'Modification de la carte ID 84 (\'The Walking Dead : Daryl Dixon\'). Visibilité : Privée.', '5.49.246.18', '2026-08-19 18:24:12'),
(19, 2, 'Mise à jour Carte', 'Modification de la carte ID 83 (\'The Walking Dead : Dead City\'). Visibilité : Privée.', '5.49.246.18', '2026-08-19 18:24:21'),
(20, 2, 'Mise à jour Carte', 'Modification de la carte ID 98 (\'His Dark Materials : À la croisée des mondes\'). Visibilité : Privée.', '5.49.246.18', '2026-08-19 18:24:33'),
(21, 2, 'Mise à jour Carte', 'Modification de la carte ID 67 (\'The Witcher\'). Visibilité : Privée.', '5.49.246.18', '2026-08-19 18:24:41'),
(22, 2, 'Mise à jour Carte', 'Modification de la carte ID 82 (\'Percy Jackson et les Olympiens\'). Visibilité : Privée.', '5.49.246.18', '2026-08-19 18:24:50'),
(23, 2, 'Mise à jour Carte', 'Modification de la carte ID 85 (\'Under the Dome\'). Visibilité : Privée.', '5.49.246.18', '2026-08-19 18:24:59'),
(24, 2, 'Reorganisation', 'L\'utilisateur a modifié l\'ordre d\'affichage de 9 carte(s).', '5.49.246.18', '2026-08-19 18:25:03'),
(25, 2, 'Création Carte', 'Création de la carte ID 104 (\'Bad Boys\'). Visibilité initiale: Privée.', '5.49.246.18', '2026-08-19 18:34:08'),
(26, 2, 'Création Carte', 'Création de la carte ID 105 (\'Bad Boys 2\'). Visibilité initiale: Privée.', '5.49.246.18', '2026-08-19 18:34:50'),
(27, 2, 'Création Carte', 'Création de la carte ID 106 (\'Bad Boys for Life\'). Visibilité initiale: Privée.', '5.49.246.18', '2026-08-19 18:35:15'),
(28, 2, 'Création Carte', 'Création de la carte ID 107 (\'Bad Boys : Ride or Die\'). Visibilité initiale: Privée.', '5.49.246.18', '2026-08-19 18:35:28'),
(29, 2, 'Mise à jour Carte', 'Modification de la carte ID 105 (\'Bad Boys 2\'). Visibilité : Privée.', '5.49.246.18', '2026-08-19 18:35:44'),
(30, 2, 'Mise à jour Carte', 'Modification de la carte ID 106 (\'Bad Boys for Life\'). Visibilité : Privée.', '5.49.246.18', '2026-08-19 18:36:01'),
(31, 2, 'Mise à jour Carte', 'Modification de la carte ID 107 (\'Bad Boys : Ride or Die\'). Visibilité : Privée.', '5.49.246.18', '2026-08-19 18:36:20'),
(32, 2, 'Reorganisation', 'L\'utilisateur a modifié l\'ordre d\'affichage de 17 carte(s).', '5.49.246.18', '2026-08-19 18:36:43'),
(33, 2, 'Incrémentation Rapide', 'Mise à jour de la carte ID 35 (\'Classroom of the Elite\') : Épisode passé à 10.', '5.49.246.18', '2026-08-19 19:15:16'),
(34, 2, 'Création Carte', 'Création de la carte ID 108 (\'The Man of Earth\'). Visibilité initiale: Privée.', '172.226.148.11', '2026-08-19 23:03:37'),
(35, 5, 'Suppression Carte', 'Suppression de la carte ID 101 (\'Cendrillon\').', '5.49.246.18', '2026-08-21 14:02:26'),
(36, 5, 'Création Carte', 'Création de la carte ID 109 (\'Harry Potter à l\'école des sorciers\'). Visibilité initiale: Privée.', '5.49.246.18', '2026-08-21 14:10:02'),
(37, 5, 'Mise à jour Carte', 'Modification de la carte ID 109 (\'Harry Potter à l\'école des sorciers\'). Visibilité : Privée.', '5.49.246.18', '2026-08-21 14:14:27'),
(38, 5, 'Mise à jour Carte', 'Modification de la carte ID 100 (\'Le Prince et moi\'). Visibilité : Privée.', '5.49.246.18', '2026-08-21 14:15:06'),
(39, 5, 'Mise à jour Carte', 'Modification de la carte ID 109 (\'Harry Potter à l\'école des sorciers\'). Visibilité : Privée.', '5.49.246.18', '2026-08-21 14:15:51'),
(40, 5, 'Création Carte', 'Création de la carte ID 110 (\'Harry Potter et la Chambre des secrets\'). Visibilité initiale: Privée.', '5.49.246.18', '2026-08-21 14:18:12'),
(41, 5, 'Reorganisation', 'L\'utilisateur a modifié l\'ordre d\'affichage de 3 carte(s).', '5.49.246.18', '2026-08-21 14:18:29'),
(42, 5, 'Reorganisation', 'L\'utilisateur a modifié l\'ordre d\'affichage de 3 carte(s).', '5.49.246.18', '2026-08-21 14:18:35'),
(43, 5, 'Création Carte', 'Création de la carte ID 111 (\'Harry Potter et le Prisonnier d\'Azkaban\'). Visibilité initiale: Privée.', '5.49.246.18', '2026-08-21 14:22:08'),
(44, 2, 'Mise à jour Carte', 'Modification de la carte ID 2 (\'One Piece\'). Visibilité : Privée.', '5.49.246.18', '2026-08-21 14:49:20'),
(45, 5, 'Mise à jour Carte', 'Modification de la carte ID 109 (\'Harry Potter à l\'école des sorciers\'). Visibilité : Privée.', '5.49.246.18', '2026-08-21 14:56:57'),
(46, 5, 'Mise à jour Carte', 'Modification de la carte ID 109 (\'Harry Potter à l\'école des sorciers\'). Visibilité : Privée.', '5.49.246.18', '2026-08-21 16:12:03'),
(47, 2, 'Incrémentation Rapide', 'Mise à jour de la carte ID 59 (\'Vampire Diaries\') : Épisode passé à 4.', '5.49.246.18', '2026-08-21 21:45:05'),
(48, 2, 'Incrémentation Rapide', 'Mise à jour de la carte ID 60 (\'The Originals\') : Épisode passé à 4.', '5.49.246.18', '2026-08-21 22:35:41'),
(49, 5, 'Mise à jour Carte', 'Modification de la carte ID 110 (\'Harry Potter et la Chambre des secrets\'). Visibilité : Privée.', '5.49.246.18', '2026-08-21 23:05:47'),
(50, 5, 'Mise à jour Carte', 'Modification de la carte ID 110 (\'Harry Potter et la Chambre des secrets\'). Visibilité : Privée.', '5.49.246.18', '2026-08-21 23:05:54'),
(51, 2, 'Reorganisation', 'L\'utilisateur a modifié l\'ordre d\'affichage de 3 carte(s).', '5.49.246.18', '2026-08-22 00:13:48'),
(52, 2, 'Reorganisation', 'L\'utilisateur a modifié l\'ordre d\'affichage de 3 carte(s).', '5.49.246.18', '2026-08-22 00:13:50'),
(53, 5, 'Mise à jour Carte', 'Modification de la carte ID 111 (\'Harry Potter et le Prisonnier d\'Azkaban\'). Visibilité : Privée.', '5.49.246.18', '2026-08-22 00:57:39'),
(54, 5, 'Création Carte', 'Création de la carte ID 112 (\'Harry Potter et la Coupe de feu\'). Visibilité initiale: Privée.', '5.49.246.18', '2026-08-22 01:01:23'),
(55, 5, 'Création Carte', 'Création de la carte ID 113 (\'Harry Potter et l\'Ordre du Phénix\'). Visibilité initiale: Privée.', '5.49.246.18', '2026-08-22 01:27:07'),
(56, 5, 'Création Carte', 'Création de la carte ID 114 (\'Harry Potter et le Prince de sang-mêlé\'). Visibilité initiale: Privée.', '5.49.246.18', '2026-08-22 01:28:46'),
(57, 5, 'Mise à jour Carte', 'Modification de la carte ID 112 (\'Harry Potter et la Coupe de feu\'). Visibilité : Privée.', '5.49.246.18', '2026-08-22 03:02:11'),
(58, 2, 'Création Carte', 'Création de la carte ID 115 (\'YouTube \'). Visibilité initiale: Privée.', '104.28.42.28', '2026-08-22 14:11:54'),
(59, 2, 'Mise à jour Carte', 'Modification de la carte ID 115 (\'Endurance et fra\'). Visibilité : Privée.', '5.49.246.18', '2026-08-22 14:43:12'),
(60, 2, 'Mise à jour Carte', 'Modification de la carte ID 115 (\'Comment l\'ENDURANCE et le FRACTIONNÉ sont complémentaires (+ une théorie sortie du chapeau)\'). Visibilité : Privée.', '5.49.246.18', '2026-08-22 14:43:53'),
(61, 2, 'Mise à jour Carte', 'Modification de la carte ID 115 (\'Comment l\'ENDURANCE et le FRACTIONNÉ sont complémentaires (+ une théorie sortie du chapeau)\'). Visibilité : Privée.', '5.49.246.18', '2026-08-22 15:18:34'),
(62, 2, 'Création Carte', 'Création de la carte ID 116 (\'The Man from Earth - Film COMPLET\'). Visibilité initiale: Privée.', '5.49.246.18', '2026-08-22 16:08:13'),
(63, 2, 'Reorganisation', 'L\'utilisateur a modifié l\'ordre d\'affichage de 2 carte(s).', '5.49.246.18', '2026-08-22 16:08:17'),
(64, 2, 'Suppression Carte', 'Suppression de la carte ID 115 (\'Comment l\'ENDURANCE et le FRACTIONNÉ sont complémentaires (+ une théorie sortie du chapeau)\').', '5.49.246.18', '2026-08-22 17:20:26'),
(65, 5, 'Mise à jour Carte', 'Modification de la carte ID 113 (\'Harry Potter et l\'Ordre du Phénix\'). Visibilité : Privée.', '5.49.246.18', '2026-08-23 01:19:16'),
(66, 5, 'Mise à jour Carte', 'Modification de la carte ID 114 (\'Harry Potter et le Prince de sang-mêlé\'). Visibilité : Privée.', '5.49.246.18', '2026-08-23 11:52:38'),
(67, 5, 'Mise à jour Carte', 'Modification de la carte ID 114 (\'Harry Potter et le Prince de sang-mêlé\'). Visibilité : Privée.', '5.49.246.18', '2026-08-23 19:04:57'),
(68, 5, 'Mise à jour Carte', 'Modification de la carte ID 114 (\'Harry Potter et le Prince de sang-mêlé\'). Visibilité : Privée.', '5.49.246.18', '2026-08-23 19:30:37'),
(69, 5, 'Création Carte', 'Création de la carte ID 117 (\'Harry Potter et les Reliques de la Mort - 1ère partie\'). Visibilité initiale: Privée.', '5.49.246.18', '2026-08-23 19:32:14'),
(70, 5, 'Création Carte', 'Création de la carte ID 118 (\'Harry Potter et les Reliques de la Mort - 2ème partie\'). Visibilité initiale: Privée.', '5.49.246.18', '2026-08-23 19:33:13'),
(71, 5, 'Mise à jour Carte', 'Modification de la carte ID 117 (\'Harry Potter et les Reliques de la Mort - 1ère partie\'). Visibilité : Privée.', '5.49.246.18', '2026-08-23 20:19:57'),
(72, 2, 'Mise à jour Carte', 'Modification de la carte ID 43 (\'Les Carnets de l\'apothicaire\'). Visibilité : Privée.', '5.49.246.18', '2026-08-23 23:22:53'),
(73, 5, 'Mise à jour Carte', 'Modification de la carte ID 118 (\'Harry Potter et les Reliques de la Mort - 2ème partie\'). Visibilité : Privée.', '5.49.246.18', '2026-08-23 23:23:12'),
(74, 2, 'Mise à jour Carte', 'Modification de la carte ID 1 (\'One Piece\'). Visibilité : Privée.', '5.49.246.18', '2026-08-23 23:23:16'),
(75, 2, 'Reorganisation', 'L\'utilisateur a modifié l\'ordre d\'affichage de 15 carte(s).', '5.49.246.18', '2026-08-23 23:23:23'),
(76, 2, 'Mise à jour Carte', 'Modification de la carte ID 55 (\'BLACK TORCH\'). Visibilité : Privée.', '5.49.246.18', '2026-08-23 23:45:06'),
(77, 2, 'Mise à jour Carte', 'Modification de la carte ID 57 (\'Mushoku Tensei\'). Visibilité : Privée.', '5.49.246.18', '2026-08-24 18:13:47'),
(78, 2, 'Mise à jour Carte', 'Modification de la carte ID 34 (\'Yuru no Tsugai\'). Visibilité : Privée.', '5.49.246.18', '2026-08-24 18:15:37'),
(79, 2, 'Mise à jour Carte', 'Modification de la carte ID 55 (\'BLACK TORCH\'). Visibilité : Privée.', '5.49.246.18', '2026-08-24 18:16:17'),
(80, 2, 'Mise à jour Carte', 'Modification de la carte ID 57 (\'Mushoku Tensei\'). Visibilité : Privée.', '5.49.246.18', '2026-08-24 18:17:14'),
(81, 2, 'Mise à jour Carte', 'Modification de la carte ID 34 (\'Yuru no Tsugai\'). Visibilité : Privée.', '5.49.246.18', '2026-08-24 18:42:37'),
(82, 2, 'Maintenance Système', 'Scan de liens en arrière-plan : 31 domaines uniques testés pour 86 cartes. 1 carte(s) impactée(s).', '5.49.246.18', '2026-08-24 21:57:32'),
(83, 2, 'Incrémentation Rapide', 'Mise à jour de la carte ID 59 (\'Vampire Diaries\') : Épisode passé à 5.', '5.49.246.18', '2026-08-25 22:45:15'),
(84, 5, 'Création Carte', 'Création de la carte ID 119 (\'The Last Sunrise\'). Visibilité initiale: Privée.', '5.49.246.18', '2026-08-26 14:15:30'),
(85, 5, 'Mise à jour Carte', 'Modification de la carte ID 119 (\'The Last Sunrise\'). Visibilité : Privée.', '5.49.246.18', '2026-08-26 15:17:11'),
(86, 2, 'Incrémentation Rapide', 'Mise à jour de la carte ID 60 (\'The Originals\') : Épisode passé à 5.', '5.49.246.18', '2026-08-26 21:43:07'),
(87, 2, 'Incrémentation Rapide', 'Mise à jour de la carte ID 59 (\'Vampire Diaries\') : Épisode passé à 6.', '5.49.246.18', '2026-08-26 22:33:17'),
(88, 2, 'Création Carte', 'Création de la carte ID 120 (\'Jumper\'). Visibilité initiale: Privée.', '140.248.41.24', '2026-08-27 11:05:33'),
(89, 2, 'Suppression Carte', 'Suppression de la carte ID 108 (\'The Man of Earth\').', '140.248.41.24', '2026-08-27 11:06:02'),
(90, 2, 'Incrémentation Rapide', 'Mise à jour de la carte ID 60 (\'The Originals\') : Épisode passé à 6.', '5.49.246.18', '2026-08-27 16:58:39'),
(91, 2, 'Mise à jour Carte', 'Modification de la carte ID 35 (\'Classroom of the Elite\'). Visibilité : Privée.', '5.49.246.18', '2026-08-27 18:03:03'),
(92, 2, 'Mise à jour Carte', 'Modification de la carte ID 57 (\'Mushoku Tensei\'). Visibilité : Privée.', '5.49.246.18', '2026-08-27 18:03:16'),
(93, 2, 'Mise à jour Carte', 'Modification de la carte ID 55 (\'BLACK TORCH\'). Visibilité : Privée.', '5.49.246.18', '2026-08-27 18:03:29'),
(94, 2, 'Mise à jour Carte', 'Modification de la carte ID 34 (\'Tsugai - Daemons of the Shadow Realm\'). Visibilité : Privée.', '5.49.246.18', '2026-08-27 18:03:50'),
(95, 2, 'Mise à jour Carte', 'Modification de la carte ID 60 (\'The Originals\'). Visibilité : Privée.', '5.49.246.18', '2026-08-27 18:04:14'),
(96, 2, 'Mise à jour Carte', 'Modification de la carte ID 59 (\'Vampire Diaries\'). Visibilité : Privée.', '5.49.246.18', '2026-08-27 18:04:26'),
(97, 2, 'Mise à jour Carte', 'Modification de la carte ID 83 (\'The Walking Dead : Dead City\'). Visibilité : Privée.', '5.49.246.18', '2026-08-27 18:04:35'),
(98, 2, 'Mise à jour Carte', 'Modification de la carte ID 84 (\'The Walking Dead : Daryl Dixon\'). Visibilité : Privée.', '5.49.246.18', '2026-08-27 18:04:44'),
(99, 2, 'Mise à jour Carte', 'Modification de la carte ID 98 (\'His Dark Materials : À la croisée des mondes\'). Visibilité : Privée.', '5.49.246.18', '2026-08-27 18:04:51'),
(100, 2, 'Mise à jour Carte', 'Modification de la carte ID 67 (\'The Witcher\'). Visibilité : Privée.', '5.49.246.18', '2026-08-27 18:05:02'),
(101, 2, 'Mise à jour Carte', 'Modification de la carte ID 82 (\'Percy Jackson et les Olympiens\'). Visibilité : Privée.', '5.49.246.18', '2026-08-27 18:05:10'),
(102, 2, 'Mise à jour Carte', 'Modification de la carte ID 85 (\'Under the Dome\'). Visibilité : Privée.', '5.49.246.18', '2026-08-27 18:05:18'),
(103, 2, 'Mise à jour Carte', 'Modification de la carte ID 35 (\'Classroom of the Elite\'). Visibilité : Privée.', '5.49.246.18', '2026-08-27 18:35:01'),
(104, 2, 'Mise à jour Carte', 'Modification de la carte ID 35 (\'Classroom of the Elite\'). Visibilité : Privée.', '5.49.246.18', '2026-08-27 18:36:44'),
(105, 2, 'Mise à jour Carte', 'Modification de la carte ID 35 (\'Classroom of the Elite\'). Visibilité : Privée.', '5.49.246.18', '2026-08-27 18:45:18'),
(106, 2, 'Mise à jour Carte', 'Modification de la carte ID 35 (\'Classroom of the Elite\'). Visibilité : Privée.', '5.49.246.18', '2026-08-27 18:45:30'),
(107, 2, 'Mise à jour Carte', 'Modification de la carte ID 57 (\'Mushoku Tensei\'). Visibilité : Privée.', '5.49.246.18', '2026-08-27 18:45:44'),
(108, 2, 'Mise à jour Carte', 'Modification de la carte ID 55 (\'BLACK TORCH\'). Visibilité : Privée.', '5.49.246.18', '2026-08-27 18:45:54'),
(109, 2, 'Mise à jour Carte', 'Modification de la carte ID 34 (\'Tsugai - Daemons of the Shadow Realm\'). Visibilité : Privée.', '5.49.246.18', '2026-08-27 18:46:04'),
(110, 2, 'Mise à jour Carte', 'Modification de la carte ID 8 (\'Bleach\'). Visibilité : Privée.', '5.49.246.18', '2026-08-27 18:46:15'),
(111, 2, 'Mise à jour Carte', 'Modification de la carte ID 43 (\'Les Carnets de l\'apothicaire\'). Visibilité : Privée.', '5.49.246.18', '2026-08-27 18:46:29'),
(112, 2, 'Mise à jour Carte', 'Modification de la carte ID 60 (\'The Originals\'). Visibilité : Privée.', '5.49.246.18', '2026-08-27 18:46:47'),
(113, 2, 'Mise à jour Carte', 'Modification de la carte ID 59 (\'Vampire Diaries\'). Visibilité : Privée.', '5.49.246.18', '2026-08-27 18:46:58'),
(114, 2, 'Mise à jour Carte', 'Modification de la carte ID 83 (\'The Walking Dead : Dead City\'). Visibilité : Privée.', '5.49.246.18', '2026-08-27 18:47:08'),
(115, 2, 'Mise à jour Carte', 'Modification de la carte ID 84 (\'The Walking Dead : Daryl Dixon\'). Visibilité : Privée.', '5.49.246.18', '2026-08-27 18:47:17'),
(116, 2, 'Mise à jour Carte', 'Modification de la carte ID 98 (\'His Dark Materials : À la croisée des mondes\'). Visibilité : Privée.', '5.49.246.18', '2026-08-27 18:47:26'),
(117, 2, 'Mise à jour Carte', 'Modification de la carte ID 67 (\'The Witcher\'). Visibilité : Privée.', '5.49.246.18', '2026-08-27 18:47:39'),
(118, 2, 'Mise à jour Carte', 'Modification de la carte ID 82 (\'Percy Jackson et les Olympiens\'). Visibilité : Privée.', '5.49.246.18', '2026-08-27 18:47:47'),
(119, 2, 'Mise à jour Carte', 'Modification de la carte ID 85 (\'Under the Dome\'). Visibilité : Privée.', '5.49.246.18', '2026-08-27 18:47:55'),
(120, 2, 'Incrémentation Rapide', 'Mise à jour de la carte ID 59 (\'Vampire Diaries\') : Épisode passé à 7.', '5.49.246.18', '2026-08-27 21:56:44'),
(121, 2, 'Incrémentation Rapide', 'Mise à jour de la carte ID 60 (\'The Originals\') : Épisode passé à 7.', '5.49.246.18', '2026-08-27 22:42:10'),
(122, 5, 'Mise à jour Carte', 'Modification de la carte ID 78 (\'Soy Luna\'). Visibilité : Privée.', '5.49.246.18', '2026-08-28 00:38:19'),
(123, 2, 'Mise à jour Carte', 'Modification de la carte ID 52 (\'Black Clover\'). Visibilité : Privée.', '5.49.246.18', '2026-08-28 18:33:46'),
(124, 2, 'Mise à jour Carte', 'Modification de la carte ID 52 (\'Black Clover\'). Visibilité : Privée.', '5.49.246.18', '2026-08-28 18:33:56'),
(125, 2, 'Mise à jour Carte', 'Modification de la carte ID 40 (\'Jujutsu Kaisen Modulo\'). Visibilité : Privée.', '5.49.246.18', '2026-08-28 18:34:15'),
(126, 2, 'Reorganisation', 'Ordre d\'affichage de 15 carte(s) modifié.', '5.49.246.18', '2026-08-28 18:35:02'),
(127, 2, 'Mise à jour Carte', 'Modification de la carte ID 1 (\'One Piece\'). Visibilité : Privée.', '5.49.246.18', '2026-08-28 18:35:11'),
(128, 2, 'Mise à jour Carte', 'Modification de la carte ID 1 (\'One Piece\'). Visibilité : Privée.', '5.49.246.18', '2026-08-28 18:36:09'),
(129, 2, 'Mise à jour Carte', 'Modification de la carte ID 40 (\'Jujutsu Kaisen Modulo\'). Visibilité : Privée.', '5.49.246.18', '2026-08-28 19:18:36'),
(130, 2, 'Mise à jour Carte', 'Modification de la carte ID 52 (\'Black Clover\'). Visibilité : Privée.', '5.49.246.18', '2026-08-28 19:18:58'),
(131, 2, 'Mise à jour Carte', 'Modification de la carte ID 52 (\'Black Clover\'). Visibilité : Privée.', '5.49.246.18', '2026-08-28 19:19:07'),
(132, 2, 'Mise à jour Carte', 'Modification de la carte ID 24 (\'Noble Reincarnation\'). Visibilité : Privée.', '5.49.246.18', '2026-08-28 19:19:59');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `details`, `ip_address`, `created_at`) VALUES
(133, 2, 'Mise à jour Carte', 'Modification de la carte ID 5 (\'Frieren\'). Visibilité : Privée.', '5.49.246.18', '2026-08-28 19:20:18'),
(134, 2, 'Mise à jour Carte', 'Modification de la carte ID 5 (\'Frieren\'). Visibilité : Privée.', '5.49.246.18', '2026-08-28 19:21:15'),
(135, 2, 'Mise à jour Carte', 'Modification de la carte ID 68 (\'Arifureta\'). Visibilité : Privée.', '5.49.246.18', '2026-08-28 19:21:34'),
(136, 2, 'Mise à jour Carte', 'Modification de la carte ID 7 (\'To Your Eternity\'). Visibilité : Privée.', '5.49.246.18', '2026-08-28 19:21:55'),
(137, 2, 'Mise à jour Carte', 'Modification de la carte ID 70 (\'Villainess Level 99\'). Visibilité : Privée.', '5.49.246.18', '2026-08-28 19:22:18'),
(138, 2, 'Mise à jour Carte', 'Modification de la carte ID 71 (\'Goblin Slayer\'). Visibilité : Privée.', '5.49.246.18', '2026-08-28 19:22:53'),
(139, 2, 'Mise à jour Carte', 'Modification de la carte ID 37 (\'Dr. STONE\'). Visibilité : Privée.', '5.49.246.18', '2026-08-28 19:23:50'),
(140, 2, 'Mise à jour Carte', 'Modification de la carte ID 36 (\'Re:ZERO\'). Visibilité : Privée.', '5.49.246.18', '2026-08-28 19:24:46'),
(141, 2, 'Mise à jour Carte', 'Modification de la carte ID 37 (\'Dr. STONE\'). Visibilité : Privée.', '5.49.246.18', '2026-08-28 19:25:36'),
(142, 2, 'Mise à jour Carte', 'Modification de la carte ID 71 (\'Goblin Slayer\'). Visibilité : Privée.', '5.49.246.18', '2026-08-28 19:25:47'),
(143, 2, 'Mise à jour Carte', 'Modification de la carte ID 36 (\'Re:ZERO\'). Visibilité : Privée.', '5.49.246.18', '2026-08-28 19:26:00'),
(144, 2, 'Création Carte', 'Création de la carte ID 121 (\'Le Quotidien du Roi Immortel\'). Visibilité initiale: Privée.', '5.49.246.18', '2026-08-28 19:27:45'),
(145, 2, 'Mise à jour Carte', 'Modification de la carte ID 121 (\'Le Quotidien du Roi Immortel\'). Visibilité : Privée.', '5.49.246.18', '2026-08-28 19:28:34'),
(146, 2, 'Création Carte', 'Création de la carte ID 122 (\'I Was Reincarnated as the 7th Prince\'). Visibilité initiale: Privée.', '5.49.246.18', '2026-08-28 19:36:30'),
(147, 2, 'Création Carte', 'Création de la carte ID 123 (\'Noble Reincarnation\'). Visibilité initiale: Privée.', '5.49.246.18', '2026-08-28 22:02:09'),
(148, 2, 'Suppression Carte', 'Suppression de la carte ID 123 (\'Noble Reincarnation\').', '5.49.246.18', '2026-08-28 22:02:18'),
(149, 2, 'Création Carte', 'Création de la carte ID 124 (\'Spy Classroom\'). Visibilité initiale: Privée.', '5.49.246.18', '2026-08-28 22:04:58'),
(150, 2, 'Création Carte', 'Création de la carte ID 125 (\'Fire Force\'). Visibilité initiale: Privée.', '5.49.246.18', '2026-08-28 22:06:58'),
(151, 2, 'Création Carte', 'Création de la carte ID 126 (\'DanMachi : Sword Oratoria\'). Visibilité initiale: Privée.', '5.49.246.18', '2026-08-28 22:10:03'),
(152, 2, 'Création Carte', 'Création de la carte ID 127 (\'Shangri-La Frontier\'). Visibilité initiale: Privée.', '5.49.246.18', '2026-08-28 22:11:34'),
(153, 2, 'Création Carte', 'Création de la carte ID 128 (\'The Devil is a Part-Timer!\'). Visibilité initiale: Privée.', '5.49.246.18', '2026-08-28 22:13:06'),
(154, 2, 'Mise à jour Carte', 'Modification de la carte ID 1 (\'One Piece\'). Visibilité : Privée.', '5.49.246.18', '2026-08-28 22:15:49'),
(155, 2, 'Mise à jour Carte', 'Modification de la carte ID 1 (\'One Piece\'). Visibilité : Privée.', '5.49.246.18', '2026-08-28 22:16:15'),
(156, 2, 'Mise à jour Carte', 'Modification de la carte ID 5 (\'Frieren\'). Visibilité : Privée.', '5.49.246.18', '2026-08-28 22:16:25'),
(157, 2, 'Mise à jour Carte', 'Modification de la carte ID 71 (\'Goblin Slayer\'). Visibilité : Privée.', '5.49.246.18', '2026-08-28 22:16:41'),
(158, 2, 'Mise à jour Carte', 'Modification de la carte ID 36 (\'Re:ZERO\'). Visibilité : Privée.', '5.49.246.18', '2026-08-28 22:16:48'),
(159, 2, 'Mise à jour Carte', 'Modification de la carte ID 43 (\'Les Carnets de l\'apothicaire\'). Visibilité : Privée.', '5.49.246.18', '2026-08-28 22:16:56'),
(160, 2, 'Mise à jour Carte', 'Modification de la carte ID 2 (\'One Piece\'). Visibilité : Privée.', '5.49.246.18', '2026-08-28 22:17:13'),
(161, 2, 'Mise à jour Carte', 'Modification de la carte ID 52 (\'Black Clover\'). Visibilité : Privée.', '5.49.246.18', '2026-08-28 22:17:20'),
(162, 2, 'Mise à jour Carte', 'Modification de la carte ID 40 (\'Jujutsu Kaisen Modulo\'). Visibilité : Privée.', '5.49.246.18', '2026-08-28 22:17:26'),
(163, 2, 'Mise à jour Carte', 'Modification de la carte ID 95 (\'La Planète des singes : L\'Affrontement\'). Visibilité : Privée.', '5.49.246.18', '2026-08-28 22:17:37'),
(164, 2, 'Mise à jour Carte', 'Modification de la carte ID 96 (\'La Planète des singes : Suprématie\'). Visibilité : Privée.', '5.49.246.18', '2026-08-28 22:17:45'),
(165, 2, 'Mise à jour Carte', 'Modification de la carte ID 97 (\'La Planète des singes : Le Nouveau Royaume\'). Visibilité : Privée.', '5.49.246.18', '2026-08-28 22:17:52'),
(166, 2, 'Mise à jour Carte', 'Modification de la carte ID 84 (\'The Walking Dead : Daryl Dixon\'). Visibilité : Privée.', '5.49.246.18', '2026-08-28 22:18:29'),
(167, 2, 'Mise à jour Carte', 'Modification de la carte ID 59 (\'Vampire Diaries\'). Visibilité : Privée.', '5.49.246.18', '2026-08-28 22:18:39'),
(168, 2, 'Mise à jour Carte', 'Modification de la carte ID 61 (\'Ordre de diffusion TVD & The originals\'). Visibilité : Privée.', '5.49.246.18', '2026-08-28 22:18:47'),
(169, 2, 'Mise à jour Carte', 'Modification de la carte ID 98 (\'His Dark Materials : À la croisée des mondes\'). Visibilité : Privée.', '5.49.246.18', '2026-08-28 22:19:00'),
(170, 2, 'Mise à jour Carte', 'Modification de la carte ID 67 (\'The Witcher\'). Visibilité : Privée.', '5.49.246.18', '2026-08-28 22:19:11'),
(171, 2, 'Mise à jour Carte', 'Modification de la carte ID 82 (\'Percy Jackson et les Olympiens\'). Visibilité : Privée.', '5.49.246.18', '2026-08-28 22:19:18');

-- --------------------------------------------------------

--
-- Structure de la table `auth_groups_users`
--

CREATE TABLE `auth_groups_users` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `group` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `auth_groups_users`
--

INSERT INTO `auth_groups_users` (`id`, `user_id`, `group`, `created_at`) VALUES
(1, 1, 'superadmin', '2026-04-11 17:01:16'),
(3, 3, 'user', '2026-04-30 14:13:10'),
(6, 2, 'admin', '2026-05-17 22:56:01'),
(7, 4, 'user', '2026-05-29 22:30:45'),
(8, 5, 'user', '2026-06-17 20:17:27');

-- --------------------------------------------------------

--
-- Structure de la table `auth_identities`
--

CREATE TABLE `auth_identities` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `type` varchar(255) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `secret` varchar(255) NOT NULL,
  `secret2` varchar(255) DEFAULT NULL,
  `expires` datetime DEFAULT NULL,
  `extra` text DEFAULT NULL,
  `force_reset` tinyint(1) NOT NULL DEFAULT 0,
  `last_used_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `auth_identities`
--

INSERT INTO `auth_identities` (`id`, `user_id`, `type`, `name`, `secret`, `secret2`, `expires`, `extra`, `force_reset`, `last_used_at`, `created_at`, `updated_at`) VALUES
(1, 1, 'email_password', NULL, 'titisland@gmail.com', '$2y$12$fQQGOXUFz0cpRjQv6KEQKunD.NyN.foC2QF30zzcvm47qdRIHtW26', NULL, NULL, 0, '2026-08-23 19:22:14', '2026-04-11 17:01:16', '2026-08-23 19:22:14'),
(2, 2, 'email_password', NULL, 'mathisfrances11@gmail.com', '$2y$12$MCy7X0OR/J0IAycNYTkrwOGAi2UygpbYVtakTyTZEOGJvE6b60BSa', NULL, NULL, 0, '2026-08-25 21:43:57', '2026-04-11 17:02:38', '2026-08-25 21:43:57'),
(3, 2, 'magic-link', NULL, 'e3fc52dba64bd3b1958f', NULL, '2026-04-30 15:11:11', NULL, 0, NULL, '2026-04-30 14:11:11', '2026-04-30 14:11:11'),
(4, 3, 'email_password', NULL, 'hugophilippe26@gmail.com', '$2y$12$9rKoqgP6n7E1vosN4EUWpu5L/lPLkyb9GrDKmIqJxQX9pzG/7drPG', NULL, NULL, 0, NULL, '2026-04-30 14:13:09', '2026-04-30 14:13:10'),
(5, 4, 'email_password', NULL, 'mathisfrances111@gmail.com', '$2y$12$q4NTrCKkkMj3kINlncokHuDcbgPaDT2SDDooXI0R5asUjUwjK1pem', NULL, NULL, 0, '2026-08-19 17:22:31', '2026-05-29 22:30:44', '2026-08-19 17:22:31'),
(6, 5, 'email_password', NULL, 'ambrefrances1@gmail.com', '$2y$12$AyjlWNvzet1MU5XhMJBDdeMjd9oGgFhKSGjIbtn3R25TWPeFUTfTG', NULL, NULL, 0, '2026-08-26 13:56:52', '2026-06-17 20:17:27', '2026-08-26 13:56:52');

-- --------------------------------------------------------

--
-- Structure de la table `auth_logins`
--

CREATE TABLE `auth_logins` (
  `id` int(10) UNSIGNED NOT NULL,
  `ip_address` varchar(255) NOT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `id_type` varchar(255) NOT NULL,
  `identifier` varchar(255) NOT NULL,
  `user_id` int(10) UNSIGNED DEFAULT NULL,
  `date` datetime NOT NULL,
  `success` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `auth_logins`
--

INSERT INTO `auth_logins` (`id`, `ip_address`, `user_agent`, `id_type`, `identifier`, `user_id`, `date`, `success`) VALUES
(1, '5.49.246.18', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', 'email_password', 'mathisfrances11@gmail.com', 2, '2026-08-19 18:19:41', 1),
(2, '140.248.41.24', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15', 'email_password', 'mathisfrances11@gmail.com', 2, '2026-08-19 18:28:03', 1),
(3, '5.49.246.18', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0', 'email_password', 'ambrefrances1@gmail.com', 5, '2026-08-21 14:00:10', 1),
(4, '5.49.246.18', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', 'email_password', 'mathisfrances11@gmail.com', 2, '2026-08-22 14:02:52', 1),
(5, '104.28.42.28', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15', 'email_password', 'mathisfrances11@gmail.com', 2, '2026-08-22 14:11:02', 1),
(6, '5.49.246.18', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', 'email_password', 'mathisfrances11@gmail.com', 2, '2026-08-22 15:19:07', 1),
(7, '5.49.246.18', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', 'email_password', 'titisland@gmail.com', 1, '2026-08-23 19:22:14', 1),
(8, '5.49.246.18', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', 'email_password', 'mathisfrances11@gmail.com', NULL, '2026-08-23 19:23:04', 0),
(9, '5.49.246.18', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', 'email_password', 'mathisfrances11@gmail.com', NULL, '2026-08-23 19:23:13', 0),
(10, '5.49.246.18', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', 'email_password', 'mathisfrances11@gmail.com', 2, '2026-08-23 19:23:20', 1),
(11, '5.49.246.18', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', 'email_password', 'mathisfrances11@gmail.com', 2, '2026-08-23 19:23:29', 1),
(12, '5.49.246.18', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', 'email_password', 'mathisfrances11@gmail.com', 2, '2026-08-23 19:23:51', 1),
(13, '104.28.42.18', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15', 'email_password', 'mathisfrances11@gmail.com', 2, '2026-08-25 11:28:33', 1),
(14, '5.49.246.18', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', 'email_password', 'mathisfrances11@gmail.com', 2, '2026-08-25 21:43:57', 1),
(15, '5.49.246.18', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/30.0 Chrome/143.0.0.0 Mobile Safari/537.36', 'email_password', 'ambrefrances1@gmail.com', 5, '2026-08-26 13:56:52', 1);

-- --------------------------------------------------------

--
-- Structure de la table `auth_permissions_users`
--

CREATE TABLE `auth_permissions_users` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `permission` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `auth_remember_tokens`
--

CREATE TABLE `auth_remember_tokens` (
  `id` int(10) UNSIGNED NOT NULL,
  `selector` varchar(255) NOT NULL,
  `hashedValidator` varchar(255) NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `expires` datetime NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `auth_remember_tokens`
--

INSERT INTO `auth_remember_tokens` (`id`, `selector`, `hashedValidator`, `user_id`, `expires`, `created_at`, `updated_at`) VALUES
(3, 'b613017008433af034b316b0', 'a9e9cf9725c1565e98a449dc2966b113beca7386e06d15f96995a7b115e5ea8a', 5, '2026-09-25 14:12:47', '2026-08-21 14:00:10', '2026-08-26 14:12:47'),
(9, 'edf66d236d1e2d4435974edb', 'f6f1bd3b4a716abc6a0328c63d7573b8b619ab5971c1422ae55106d791a595f1', 2, '2026-09-22 19:23:29', '2026-08-23 19:23:29', '2026-08-23 19:23:29'),
(10, 'bcbd2caf3c12583c58e86945', 'b2d0d1ce70745e4b48232b7d918012aea6c552243bb327cc102c0337778b7ead', 2, '2026-09-24 17:35:24', '2026-08-23 19:23:51', '2026-08-25 17:35:24'),
(11, 'aef58ce735821744ad6a3ee9', 'f59179256bae9d3126c72b4b0ec7db3b311949a7832d8d598f9ac6f1e22c34b4', 2, '2026-09-26 11:04:23', '2026-08-25 11:28:33', '2026-08-27 11:04:23'),
(12, 'a77d2eace6a5cabe80e44d73', '9c656a39920db482d6df1cca3574881235eab59a93bc4803b5ea30a6168dad8f', 2, '2026-09-27 21:58:39', '2026-08-25 21:43:57', '2026-08-28 21:58:39'),
(13, 'ab39a454fbad97c127d6aa07', 'e4e7c4e403ed218df1cef0259a872c602b63e5d8bdc580cfa6b6ab3cab2d7f5a', 5, '2026-09-27 00:37:29', '2026-08-26 13:56:52', '2026-08-28 00:37:29');

-- --------------------------------------------------------

--
-- Structure de la table `auth_token_logins`
--

CREATE TABLE `auth_token_logins` (
  `id` int(10) UNSIGNED NOT NULL,
  `ip_address` varchar(255) NOT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `id_type` varchar(255) NOT NULL,
  `identifier` varchar(255) NOT NULL,
  `user_id` int(10) UNSIGNED DEFAULT NULL,
  `date` datetime NOT NULL,
  `success` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `cron_logs`
--

CREATE TABLE `cron_logs` (
  `id` int(10) UNSIGNED NOT NULL,
  `item_id` int(10) UNSIGNED DEFAULT NULL,
  `titre` varchar(100) DEFAULT NULL,
  `url_testee` text DEFAULT NULL,
  `code_erreur` int(11) DEFAULT NULL,
  `task_name` varchar(50) NOT NULL,
  `last_run` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `cron_logs`
--

INSERT INTO `cron_logs` (`id`, `item_id`, `titre`, `url_testee`, `code_erreur`, `task_name`, `last_run`) VALUES
(1, 22, 'Netflix', 'https://www.netflix.com/browse', 0, 'check_dead_links', '2026-08-24 21:57:14');

-- --------------------------------------------------------

--
-- Structure de la table `division`
--

CREATE TABLE `division` (
  `id` int(10) UNSIGNED NOT NULL,
  `id_header` int(10) UNSIGNED NOT NULL,
  `nom` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `division`
--

INSERT INTO `division` (`id`, `id_header`, `nom`) VALUES
(1, 1, 'Animés'),
(2, 1, 'Mangas'),
(3, 2, 'Films'),
(4, 2, 'Séries'),
(5, 3, 'YouTube'),
(6, 4, 'Payant/Tout-en-un'),
(7, 4, 'Streaming Animés'),
(8, 4, 'Lecture Mangas'),
(9, 4, 'Streaming Films'),
(10, 4, 'Streaming Séries'),
(11, 5, 'Utilitaires Web'),
(12, 5, 'Autres');

-- --------------------------------------------------------

--
-- Structure de la table `header`
--

CREATE TABLE `header` (
  `id` int(10) UNSIGNED NOT NULL,
  `nom` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `header`
--

INSERT INTO `header` (`id`, `nom`) VALUES
(1, 'Animés & Mangas'),
(2, 'Films & Séries'),
(3, 'YouTube'),
(4, 'Liens'),
(5, 'Outils');

-- --------------------------------------------------------

--
-- Structure de la table `item`
--

CREATE TABLE `item` (
  `id` int(10) UNSIGNED NOT NULL,
  `id_user` int(10) UNSIGNED NOT NULL,
  `is_public` tinyint(1) NOT NULL DEFAULT 0,
  `id_division` int(10) UNSIGNED NOT NULL,
  `sous_categorie` varchar(100) DEFAULT NULL,
  `titre` varchar(100) NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'Aucun',
  `image` varchar(255) DEFAULT NULL,
  `lien` text DEFAULT NULL,
  `link_status` varchar(20) NOT NULL DEFAULT 'ok',
  `description` text DEFAULT NULL,
  `episode` varchar(10) DEFAULT NULL,
  `total_episodes` int(11) DEFAULT NULL,
  `saison` int(11) DEFAULT NULL,
  `total_saisons` int(11) DEFAULT NULL,
  `position` int(11) DEFAULT 0,
  `date_sortie` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `item`
--

INSERT INTO `item` (`id`, `id_user`, `is_public`, `id_division`, `sous_categorie`, `titre`, `status`, `image`, `lien`, `link_status`, `description`, `episode`, `total_episodes`, `saison`, `total_saisons`, `position`, `date_sortie`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 2, 0, 1, 'En Pause', 'One Piece', 'En pause', 'https://image.tmdb.org/t/p/w500/8f33Q5AuM2G5ZqFeusbIqDjr3cI.jpg', 'https://voir-anime.to/anime/one-piece/one-piece-{ep4}-vostfr/', 'ok', 'Il fut un temps où Gold Roger était le plus grand de tous les pirates, le \"Roi des Pirates\" était son surnom. A sa mort, son trésor d\'une valeur inestimable connu sous le nom de \"One Piece\" fut caché quelque part sur \"Grand Line\". De nombreux pira...', '1141', NULL, NULL, NULL, 4, NULL, NULL, NULL, '2026-08-28 22:16:15'),
(2, 2, 0, 2, NULL, 'One Piece', 'En cours', 'https://www.myutaku.com/media/mangas/12.jpg', 'https://www.scan-vf.net/one_piece/chapitre-{ep}', 'ok', 'Une aventure en haute mer légendaire et unique en son genre. Monkey D. Luffy est un jeune aventurier...', '1192', NULL, 0, NULL, 0, '2026-08-28 18:00:00', NULL, NULL, '2026-08-28 22:17:13'),
(5, 2, 0, 1, 'En Pause', 'Frieren', 'En pause', 'https://image.tmdb.org/t/p/w500/j8K7vgF3Kp5T6EwJvez9B4it6CB.jpg', 'https://voir-anime.to/anime/sousou-no-frieren-{s}/sousou-no-frieren-{s}-{ep2}-vostfr/', 'ok', 'L’elfe Frieren a vaincu le roi des démons aux côtés du groupe mené par le jeune héros Himmel. Après dix années d’efforts, ils ont ramené la paix dans le royaume. Parce qu’elle est une elfe, Frieren peut vivre plus de mille ans. Elle part seule en ...', '3', 10, 2, 2, 7, NULL, NULL, NULL, '2026-08-28 22:16:25'),
(7, 2, 0, 1, 'En Pause', 'To Your Eternity', 'En pause', 'https://image.tmdb.org/t/p/w500/bohMYRVSIG68md0zQobyWbV4S8e.jpg', 'https://voir-anime.to/anime/fumetsu-no-anata-e-{s}/fumetsu-no-anata-e-{s}-{ep2}-vostfr/', 'ok', 'Un garçon solitaire errant dans les régions arctiques de l\'Amérique du Nord rencontre un loup. Tous deux deviennent rapidement amis, dépendant l\'un de l\'autre pour survivre dans cet environnement hostile. Mais ce garçon a une histoire et sa rencon...', '9', 22, 3, 3, 9, NULL, NULL, NULL, '2026-08-28 19:21:55'),
(8, 2, 0, 1, 'En Pause', 'Bleach', 'En pause', 'https://image.tmdb.org/t/p/w500/e0kKmeM8R7Kersh5N2PPzIRNRhr.jpg', 'https://franime.fr/anime/bleach?s={s}&ep={ep}&lang=vo&anime_id=244', 'ok', 'Adolescent de quinze ans, Ichigo Kurosaki possède un don particulier : celui de voir les esprits. Un jour, il croise la route d\'une belle Shinigami (un être spirituel) en train de pourchasser une « âme perdue », un esprit maléfique qui hante notre...', '155', 366, 1, 2, 5, NULL, NULL, NULL, '2026-08-28 18:35:02'),
(10, 1, 1, 7, NULL, 'VoirAnime', 'Aucun', 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQdYwTRt_o2nzbUEQuhIf36xoD7DC5rpxP6vg&s', 'https://voir-anime.to/', 'ok', '', '', NULL, 0, NULL, 0, NULL, NULL, NULL, NULL),
(12, 1, 1, 10, NULL, 'PapaduStream', 'Aucun', '', 'https://papadustream.sarl/', 'ok', '', '', NULL, 0, NULL, 0, NULL, NULL, NULL, '2026-08-01 18:07:42'),
(13, 1, 1, 10, NULL, 'PLR', 'Aucun', NULL, 'https://sites.google.com/view/prl-series/accueil?authuser=0', 'ok', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(14, 1, 1, 7, NULL, 'Franime', 'Aucun', 'https://linktr.ee/og/image/franime.jpg', 'https://franime.fr/', 'ok', '', '', NULL, 0, NULL, 0, NULL, NULL, NULL, NULL),
(16, 1, 1, 8, NULL, 'Lelmanga', 'Aucun', 'https://img.themesinfo.com/i/1/387/wordpress-theme-mangareader-q6z9a-m.jpg', 'https://www.lelmanga.com/', 'ok', '', '', NULL, 0, NULL, 2, NULL, NULL, NULL, NULL),
(17, 1, 1, 8, NULL, 'ScanVf', 'Aucun', NULL, 'https://www.scan-vf.net/', 'ok', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(19, 1, 1, 8, NULL, 'Sushiscan', 'Aucun', '', 'https://sushiscan.net', 'ok', '', '', NULL, 0, NULL, 1, NULL, NULL, NULL, NULL),
(20, 1, 1, 9, NULL, 'PLR', 'Aucun', NULL, 'https://sites.google.com/view/teamprl/', 'ok', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(21, 1, 1, 6, 'Gratuit', 'Wiflix', 'Aucun', '', 'https://go-fle.site', 'ok', '', NULL, NULL, 0, NULL, 4, NULL, NULL, NULL, '2026-08-19 17:31:35'),
(22, 1, 1, 6, 'Payant', 'Netflix', 'Aucun', 'https://images.ctfassets.net/4cd45et68cgf/Rx83JoRDMkYNlMC9MKzcB/2b14d5a59fc3937afd3f03191e19502d/Netflix-Symbol.png?w=700&h=456', 'https://www.netflix.com/browse', 'dead', '', NULL, NULL, 0, NULL, 0, NULL, NULL, NULL, '2026-08-24 21:57:21'),
(24, 2, 0, 1, 'En Pause', 'Noble Reincarnation', 'En pause', 'https://image.tmdb.org/t/p/w500/ggxUYlw7a3eVegnXDv8aCDiLccJ.jpg', 'https://voir-anime.to/anime/noble-reincarnation-born-blessed-so-ill-obtain-ultimate-power/noble-reincarnation-born-blessed-so-ill-obtain-ultimate-power-{ep2}-vostfr/', 'ok', 'En tant que treizième prince de la famille royale, Noah a toujours mené une vie paisible, loin des intrigues liées à la succession impériale. Mais tout bascule lorsque le prince héritier meurt soudainement, ouvrant la voie à une bataille intestine...', '2', 12, 1, 1, 6, NULL, NULL, NULL, '2026-08-28 19:19:59'),
(25, 1, 1, 11, NULL, 'Audio To Text', 'Aucun', NULL, 'https://editor.flixier.com/transcribe?fx_source=search&lang=en&fx_campaign=convert-audio-to-text&fx_medium=tools', 'ok', 'Convertir les fichiers audio en textes', NULL, NULL, NULL, NULL, 4, NULL, NULL, NULL, '2026-08-24 21:57:21'),
(26, 1, 1, 11, NULL, 'Bootstrap Icons', 'Aucun', NULL, 'https://icons.getbootstrap.com', 'ok', 'Bibliothèque d\'icônes', NULL, NULL, NULL, NULL, 5, NULL, NULL, NULL, '2026-08-19 17:46:12'),
(27, 1, 1, 6, 'Payant', 'Prime Video', 'Aucun', 'https://cdn.prod.website-files.com/63f46dc8ada663b2260ad042/651e7514b3a51ee790163981_Amazon%20-%20Prime%20Video%20(2).jpg', 'https://www.primevideo.com/', 'ok', '', NULL, NULL, 0, NULL, 1, NULL, NULL, NULL, '2026-08-19 17:31:35'),
(28, 1, 1, 11, NULL, 'ClipDrop', 'Aucun', '', 'https://clipdrop.co/', 'ok', 'Administrer des images', NULL, NULL, 0, NULL, 6, NULL, NULL, NULL, '2026-08-19 17:46:12'),
(30, 1, 1, 11, NULL, 'Durable', 'Aucun', '', 'https://app.durable.co/dashboard', 'ok', 'Générer des sites web', '', NULL, 0, NULL, 7, NULL, NULL, NULL, '2026-08-19 17:46:12'),
(31, 1, 1, 11, NULL, 'Fotor', 'Aucun', NULL, 'https://www.fotor.com/', 'ok', 'conceptions et éditions d\'images', NULL, NULL, NULL, NULL, 8, NULL, NULL, NULL, '2026-08-19 17:46:12'),
(32, 1, 1, 11, 'IA', 'Krea.ai', 'Aucun', '', 'https://www.krea.ai/apps/image/realtime', 'ok', 'Générer des Images', NULL, NULL, NULL, NULL, 3, NULL, NULL, NULL, '2026-08-19 17:46:12'),
(33, 1, 1, 11, NULL, 'obfuscator', 'Aucun', NULL, 'https://obfuscator.io/', 'ok', 'crypter les scripts javascripts', NULL, NULL, NULL, NULL, 9, NULL, NULL, NULL, '2026-08-19 17:46:12'),
(34, 2, 0, 1, 'En cours', 'Tsugai - Daemons of the Shadow Realm', 'En cours', 'https://image.tmdb.org/t/p/w500/mNqW2jnAogZa0nJ94q1LUum8Hos.jpg', 'https://franime.fr/anime/daemons-of-the-shadow-realm?s={s}&ep={ep}&lang=vo&anime_id=50023', 'ok', 'Yuru, le chasseur, vit séparé de sa sœur jumelle Asa, enfermée dans une prison pour satisfaire un rituel. Tous deux ignorent la vérité sur leur naissance et lorsque leur paisible village est attaqué par de mystérieux ennemis, Yuru découvre qu’il p...', '21', 24, 1, 1, 3, '2026-08-29 15:00:00', NULL, NULL, '2026-08-28 18:35:02'),
(35, 2, 0, 1, 'En cours', 'Classroom of the Elite', 'En cours', 'https://image.tmdb.org/t/p/w500/mmhx3dImdsfYpcFm3J1tlQt5IRN.jpg', 'https://franime.fr/anime/classroom-of-the-elite?s={s}&ep={ep}&lang=vo&anime_id=13503', 'ok', 'Kiyotaka Ayanokôji intègre le prestigieux lycée de haut niveau de Tokyo où, une fois le diplôme en poche, quasiment 100 % des élèves trouvent un travail ou sont reçus à l’université. Pas de chance, il se retrouve dans la 2de D où finissent tous le...', '10', 16, 4, 4, 0, NULL, NULL, NULL, '2026-08-28 18:35:02'),
(36, 2, 0, 1, 'A Voir', 'Re:ZERO', 'À voir', 'https://image.tmdb.org/t/p/w500/ccG0ZfXOQ0834bIus4SwZrXtkyM.jpg', 'https://voir-anime.to/anime/rezero-kara-hajimeru-isekai-seikatsu-s{s}/re-zero-kara-hajimeru-isekai-seikatsu-saison-{s}-{ep2}-vostfr/', 'ok', 'Subaru Natsuki a basculé dans un monde fantastique où il fait la connaissance d’Émilia, une jeune fille aux longs cheveux d’argent qu’il jure de protéger. Malheureusement, le jeune homme ne résiste pas longtemps en se faisant tuer rapidement. Pour...', '1', 16, 3, 4, 13, NULL, NULL, NULL, '2026-08-28 22:16:48'),
(37, 2, 0, 1, 'A Voir', 'Dr. STONE', 'À voir', 'https://image.tmdb.org/t/p/w500/dLlnzbDCblBXcJqFLXyvN43NIwp.jpg', 'https://voir-anime.to/anime/dr-stone-{s}-science-future/dr-stone-{s}-{ep2}-vostfr/', 'ok', 'Plusieurs milliers d\'années après un mystérieux phénomène qui a transformé toute l\'humanité en pierre, Senku, un lycéen extrêmement intelligent et animé par un esprit scientifique, se réveille. Face à ce monde figé, où toutes les civilisations se ...', '1', 37, 4, 4, 12, NULL, NULL, NULL, '2026-08-28 19:25:36'),
(38, 1, 1, 11, 'IA', 'Gemini', 'Aucun', '', 'https://gemini.google.com/app?hl=fr', 'ok', '', NULL, NULL, 0, NULL, 1, NULL, NULL, NULL, '2026-08-19 17:46:12'),
(39, 2, 0, 12, NULL, 'Suivi des comptes', 'Aucun', '', 'https://summury.22web.org/suivi-comptes/index.php', 'ok', '', '', NULL, 0, NULL, 0, NULL, NULL, NULL, '2026-07-25 12:51:36'),
(40, 2, 0, 2, NULL, 'Jujutsu Kaisen Modulo', 'En pause', 'https://www.myutaku.com/media/mangas/88950.jpg?1757883349', 'https://www.scan-vf.net/jujutsu-kaisen-modulo/chapitre-{ep}', 'ok', '68 ans apres la victoire sur Ryomen Sukuna, une nouvelle generation d’exorcistes s’entraine pour prendre la releve. Yuka et Tsurugi, petits-enfants des surdoues Yuta Okkotsu et Maki Zenin, sont bien decides a devenir aussi puissants que leurs pred...', '5', 25, 0, 3, 2, NULL, NULL, NULL, '2026-08-28 22:17:26'),
(41, 2, 1, 12, NULL, 'LivesPalmes', 'Aucun', '', 'https://livepalmes.web.app/', 'ok', 'LivePalmes (FFESSM) : suivez la nage avec palmes en direct, consultez les records et les archives.', NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2026-08-19 17:48:17'),
(43, 2, 0, 1, 'A Voir', 'Les Carnets de l\'apothicaire', 'À voir', 'https://image.tmdb.org/t/p/w500/47pSay5Ao7SFeyQBZVkW5ifyhAZ.jpg', 'https://voir-anime.to/anime/the-apothecary-diaries/the-apothecary-diaries-{ep2}-vostfr/', 'ok', 'Formée dès son plus jeune âge par son père apothicaire, Mao Mao est un jour vendue comme servante au palais de l\'empereur. Prisonnière dans les arcanes du pouvoir, elle attire l’attention de Jinshi, un séduisant haut fonctionnaire qui la promeut l...', '1', 48, 1, 1, 14, NULL, NULL, NULL, '2026-08-28 22:16:56'),
(47, 2, 0, 12, NULL, 'Liens très privés', 'Aucun', '', 'https://prive.titiss.space', 'ok', '', '', NULL, 0, NULL, 2, NULL, NULL, NULL, '2026-07-25 12:51:36'),
(52, 2, 0, 2, NULL, 'Black Clover', 'En pause', 'https://image.tmdb.org/t/p/w500/p3rUhlE81nWxPqpPR8F2u7a01Tl.jpg', 'https://www.scan-vf.net/black-clover/chapitre-{ep}', 'ok', 'Asta et Yuno ont été abandonné ensemble à la même église, et sont inséparables depuis. Enfants, ils promirent qu\'ils seront en compétition pour voir qui sera le prochain Mage Empereur. Toutefois, en grandissant, quelques différences entre eux émer...', '356', 392, 0, 0, 1, NULL, NULL, NULL, '2026-08-28 22:17:20'),
(53, 1, 1, 6, 'Gratuit', 'Nakastream', 'Aucun', '', 'https://nakastream.wiki/', 'ok', '', NULL, NULL, 0, NULL, 3, NULL, NULL, NULL, '2026-08-19 17:31:35'),
(54, 2, 0, 12, NULL, 'Site de troll', 'Aucun', '', 'https://mathis.likesyou.org/troll/amfs/Trouve-tu_le_site_interessant', 'ok', '', '', NULL, 0, NULL, 3, NULL, NULL, NULL, '2026-07-25 12:51:36'),
(55, 2, 0, 1, 'En cours', 'BLACK TORCH', 'En cours', 'https://image.tmdb.org/t/p/w500/9tBZp0njtOeN7UqLnWBZB6Jf7VQ.jpg', 'https://franime.fr/anime/black-torch?s={s}&ep={ep}&lang=vo&anime_id=49656', 'ok', 'Adolescent au grand cœur capable de communiquer avec le monde animal, Jiro est issu d\'une longue lignée de ninjas. Lorsqu\'il rencontre Rago, un mystérieux chat mononoke, le monde des humains et celui des esprits entrent en collision ! Une agence d...', '9', 12, 1, 1, 2, '2026-08-29 15:00:00', NULL, NULL, '2026-08-28 18:35:02'),
(57, 2, 0, 1, 'En cours', 'Mushoku Tensei', 'En cours', 'https://image.tmdb.org/t/p/w500/tn2mxPYSSUPHgfcAe5SCga1DO0i.jpg', 'https://franime.fr/anime/mushoku-tensei-jobless-reincarnation?s={s}&ep={ep}&lang=vo&anime_id=42323', 'ok', '« Ici, je vais me transcender ! » Un anonyme de 34 ans, célibataire endurci, reclus et au chômage se fait écraser par un camion peu après avoir été chassé de la maison familiale. Quelle ne fut pas sa surprise lorsqu\'il se réveilla bébé dans un mon...', '10', 14, 3, 3, 1, '2026-08-30 17:00:00', NULL, NULL, '2026-08-28 18:35:02'),
(58, 2, 0, 4, NULL, 'Game of Thrones', 'À voir', 'https://image.tmdb.org/t/p/w500/eRMfekBOnwyE9G0ffyEJIBOjX2n.jpg', 'https://nakastream.tv/player?title=Game%20of%20Thrones&id=339&poster=/eRMfekBOnwyE9G0ffyEJIBOjX2n.jpg&type=tv&season={s}&episode={ep}', 'ok', 'Il y a très longtemps, à une époque oubliée, une force a détruit l\'équilibre des saisons. Dans un pa...', '1', NULL, 1, NULL, 0, NULL, '2026-07-07 19:32:21', '2026-07-07 19:31:19', '2026-07-07 19:32:21'),
(59, 2, 0, 4, 'TVD & The Originals', 'Vampire Diaries', 'En cours', 'https://image.tmdb.org/t/p/w500/4RHhqEdI2VV5wHp0rLmKAg9t9h6.jpg', 'https://nakastream.tv/player?title=Vampire%20Diaries&id=1434&poster=/4RHhqEdI2VV5wHp0rLmKAg9t9h6.jpg&type=tv&season={s}&episode={ep}', 'ok', 'Quatre mois après le tragique accident de voiture qui a tué leurs parents, Elena Gilbert, 17 ans, et son frère Jeremy, 15 ans, essaient encore de s\'adapter à cette nouvelle réalité. Belle et populaire, l\'adolescente poursuit ses études au Mystic F...', '7', 22, 6, 8, 2, NULL, NULL, '2026-07-07 19:33:46', '2026-08-28 22:18:39'),
(60, 2, 0, 4, 'TVD & The Originals', 'The Originals', 'En cours', 'https://image.tmdb.org/t/p/w500/keJOhJXGiLL54EW6QocbyvQGquA.jpg', 'https://nakastream.tv/player?title=The%20Originals&id=1438&poster=/keJOhJXGiLL54EW6QocbyvQGquA.jpg&type=tv&season={s}&episode={ep}', 'ok', 'Le vampire originel Klaus fait son retour au Vieux Carré, un quartier français de la Nouvelle Orléans. Dans cette ville qu’il a aidé à construire quelques siècles plus tôt, il y retrouve son ancien protégé, le diabolique et charismatique Marcel. D...', '7', 22, 2, 5, 1, NULL, NULL, '2026-07-07 19:35:06', '2026-08-27 22:42:10'),
(61, 2, 0, 4, 'TVD & The Originals', 'Ordre de diffusion TVD & The originals', 'Terminé', '', 'https://drive.google.com/drive/folders/1fd1YxKtcuBG0xH5TnCoL2po_BS7aOYT_?usp=sharing', 'ok', 'Capture n°4', NULL, NULL, NULL, NULL, 0, NULL, NULL, '2026-07-07 19:44:52', '2026-08-28 22:18:47'),
(62, 1, 1, 6, 'Payant', 'Canal +', 'Aucun', '', 'https://www.canalplus.com/?from=pass', 'ok', '', NULL, NULL, 0, NULL, 2, NULL, NULL, '2026-07-07 19:47:56', '2026-08-19 17:31:35'),
(63, 2, 0, 4, NULL, 'The Protector', 'En cours', 'https://image.tmdb.org/t/p/w500/v3cYsLksGX1baCYtn2AQa2R5HDR.jpg', '', 'ok', '', '', NULL, 0, NULL, 0, NULL, '2026-07-09 21:22:53', '2026-07-09 21:18:46', '2026-07-09 21:22:53'),
(66, 2, 0, 4, NULL, 'Le Protecteur d\'Istanbul', 'À voir', 'https://image.tmdb.org/t/p/w500/mj6z8wMzcYPt9pwJqHxy0Avlnum.jpg', 'https://papadustream.rentals/cat-series/drame-s/1287-le-protecteur-distanbul-c8a/{s}-saison/{ep}-episode.html', 'ok', 'Après avoir découvert ce qui le lie à un ancien ordre secret, un jeune homme de l\'Istanbul moderne entreprend de sauver la ville des griffes d\'un ennemi immortel.', '1', NULL, 4, NULL, 3, NULL, '2026-07-20 22:38:08', '2026-07-09 22:29:20', '2026-07-20 22:38:08'),
(67, 2, 0, 4, 'En Pause', 'The Witcher', 'En pause', 'https://image.tmdb.org/t/p/w500/rhErSlk0M236rNFertVAZa9lz9S.jpg', 'https://papadustream.sarl/cat-series/aventure-s/4328-the-witcher/{s}-saison/{ep}-episode.html', 'ok', 'Le sorcier Geralt, un chasseur de monstres mutant, se bat pour trouver sa place dans un monde où les humains se révèlent souvent plus vicieux que les bêtes.', '1', 8, 4, 4, 6, NULL, NULL, '2026-07-11 14:18:32', '2026-08-28 22:19:11'),
(68, 2, 0, 1, 'En Pause', 'Arifureta', 'En pause', 'https://image.tmdb.org/t/p/w500/3vwcB2MtQA1VZMCljCRSrDzNzdj.jpg', 'https://voir-anime.to/anime/arifureta-shokugyou-de-sekai-saikyou-{s}/arifureta-shokugyou-de-sekai-saikyou-{s}-{ep2}-vostfr/', 'ok', 'Hajime Nagumo, véritable souffre-douleur, se retrouve transporté avec toute sa classe dans un autre monde. Alors que ses camarades acquièrent des techniques de combat ultra puissantes, Hajime se retrouve doté d’une modeste compétence. Suite à la m...', '1', 16, 3, 3, 8, NULL, NULL, '2026-07-16 19:31:41', '2026-08-28 19:21:34'),
(69, 2, 0, 1, NULL, 'A Playthrough of a Certain Dude\'s VRMMO Life', 'En pause', 'https://image.tmdb.org/t/p/w500/sCLrdFdsweruRFLdN1DytcwHBZw.jpg', 'https://voir-anime.to/anime/a-playthrough-of-a-certain-dudes-vrmmo-life/a-playthrough-of-a-certain-dudes-vrmmo-life-{ep2}-vostfr/', 'ok', 'Taichi Tanaka est un Japonais ordinaire qui vient de se créer un personnage, \"Earth\", dans un tout nouveau jeu VRMMO appelé \"One More Free Life Online\" et promettant un champ d’action quasi-illimité. Dans un monde où les joueurs sont libres de déf...', '6', NULL, 1, NULL, 8, NULL, '2026-07-27 14:42:53', '2026-07-16 19:33:59', '2026-07-27 14:42:53'),
(70, 2, 0, 1, 'En Pause', 'Villainess Level 99', 'En pause', 'https://image.tmdb.org/t/p/w500/vsTjL8hO4iSUcEx7eNxAgMxDspa.jpg', 'https://franime.fr/anime/villainess-level-99-i-may-be-the-hidden-boss-but-im-not-the-demon-lord?s={s}&ep={ep}&lang=vo&anime_id=47237', 'ok', 'Cette étudiante japonaise discrète est réincarnée dans le corps d’Eumiella Dolkness, la méchante de son otome game préféré. Aspirant toujours à une vie tranquille, elle n’est pas vraiment ravie et décide d’abandonner ses fonctions maléfiques. Jusq...', '11', 12, 1, 1, 10, NULL, NULL, '2026-07-16 19:35:41', '2026-08-28 19:22:18'),
(71, 2, 0, 1, 'A Voir', 'Goblin Slayer', 'À voir', 'https://image.tmdb.org/t/p/w500/nUiT0whRDuUJKkk74L1pn8xUE2z.jpg', 'https://voir-anime.to/anime/goblin-slayer-ii/goblin-slayer-{s}-{ep2}-vostfr/', 'ok', 'Au sein de la Guilde des Aventuriers, les gobelins sont perçus comme de simples nuisibles dont l’élimination est confiée aux novices inexpérimentés. Cependant, un aventurier de rang Argent, surnommé le « Goblin Slayer », discerne la véritable natu...', '1', 12, 2, 2, 11, NULL, NULL, '2026-07-16 19:37:51', '2026-08-28 22:16:41'),
(72, 1, 1, 11, 'IA', 'Claude Code', 'Aucun', '', 'https://claude.ai/new', 'ok', '', NULL, NULL, NULL, NULL, 0, NULL, NULL, '2026-07-19 12:23:28', '2026-08-19 17:46:12'),
(73, 2, 0, 12, NULL, 'Intranap du pec', 'Aucun', '', 'https://pec-intranap.is-best.net/', 'ok', '', NULL, NULL, NULL, NULL, 4, NULL, NULL, '2026-07-19 16:26:59', '2026-07-25 12:51:36'),
(74, 2, 0, 12, NULL, 'Fit Analitics', 'Aucun', '', 'https://fitanalitics.likesyou.org/', 'ok', '', NULL, NULL, NULL, NULL, 5, NULL, NULL, '2026-07-20 22:33:03', '2026-07-25 12:51:36'),
(75, 2, 1, 12, NULL, 'Calculateur MG&M', 'Aucun', '', 'https://cmg-navy.22web.org/', 'ok', '', NULL, NULL, NULL, NULL, 6, NULL, NULL, '2026-07-24 15:25:22', '2026-08-19 17:48:45'),
(78, 5, 0, 4, NULL, 'Soy Luna', 'En cours', 'https://image.tmdb.org/t/p/w500/4JDmIzhNF7aMsDGlxVwkQ9kv9E6.jpg', 'https://nakastream.tv/player?title=Soy%20Luna&id=8332&poster=/4JDmIzhNF7aMsDGlxVwkQ9kv9E6.jpg&type=tv&season={s}&episode={ep}', 'ok', 'Luna glisse avec bonheur sur la vie comme sur ses rollers ! Comme toutes les jeunes filles de son âge, elle vit avec sa famille entourée d’amis et découvre la vie entre ses cours et son job de serveuse. Mais ce qu’elle aime par-dessus tout, c’est ...', '04', 60, 3, 3, 0, NULL, NULL, '2026-08-10 20:37:29', '2026-08-28 00:38:19'),
(79, 2, 0, 3, 'En Pause', 'Oppenheimer', 'En pause', 'https://image.tmdb.org/t/p/w500/boAUuJBeID7VNp4L7LNMQs8mfQS.jpg', 'https://nakastream.tv/player?title=Oppenheimer&id=1065&poster=/boAUuJBeID7VNp4L7LNMQs8mfQS.jpg&type=movie', 'ok', 'Temps : 2:28:00', NULL, NULL, NULL, NULL, 16, NULL, NULL, '2026-08-10 21:11:30', '2026-08-19 18:36:43');
INSERT INTO `item` (`id`, `id_user`, `is_public`, `id_division`, `sous_categorie`, `titre`, `status`, `image`, `lien`, `link_status`, `description`, `episode`, `total_episodes`, `saison`, `total_saisons`, `position`, `date_sortie`, `deleted_at`, `created_at`, `updated_at`) VALUES
(80, 5, 0, 4, NULL, 'The Rookie : Le Flic de Los Angeles', 'En cours', 'https://image.tmdb.org/t/p/w500/aOXBLBRg7M5D2Zrs5luKD5cDB8O.jpg', 'https://nakastream.tv/player?id=334&title=The+Rookie+%3A+Le+Flic+de+Los+Angeles&type=tv&poster=%2FaOXBLBRg7M5D2Zrs5luKD5cDB8O.jpg&season={s}&episode={ep}&backdrop=%2F6iNWfGVCEfASDdlNb05TP5nG0ll.jpg', 'ok', 'John Nolan, le rookie le plus âgé du LAPD, utilise son expérience de vie, sa détermination et son sens de l’humour pour suivre des recrues âgées de 20 ans de moins que lui.', '2', NULL, 2, NULL, 1, NULL, NULL, '2026-08-11 00:05:24', '2026-08-11 00:05:24'),
(81, 5, 0, 4, NULL, 'Violetta', 'À voir', 'https://image.tmdb.org/t/p/w500/b3MUGJeKakAZwQa7lNJxTP1pJmD.jpg', '', 'ok', 'Violetta, c\'est l\'histoire d\'une adolescente très talentueuse qui, après avoir vécu de nombreuses années à Madrid, est retournée avec son père à Buenos Aires, sa ville natale. Elle entrera dans un studio de musique, mais suscitera la jalousie de L...', '1', NULL, 1, NULL, 2, NULL, NULL, '2026-08-11 00:09:56', '2026-08-11 00:09:56'),
(82, 2, 0, 4, 'En Pause', 'Percy Jackson et les Olympiens', 'En pause', 'https://image.tmdb.org/t/p/w500/mAX4KE8ewwuDAIzwv3WTpqE3yh7.jpg', 'https://nakastream.tv/player?title=Percy%20Jackson%20et%20les%20Olympiens&id=583&poster=/mAX4KE8ewwuDAIzwv3WTpqE3yh7.jpg&type=tv&season={s}&episode={ep}', 'ok', 'Percy Jackson a une mission dangereuse. Tout en déjouant des monstres et des dieux, il doit parcourir l’Amérique pour retourner l’Éclair primitif à Zeus et mettre fin à une guerre sans merci. Après avoir perdu sa mère, Percy trouve refuge à la Col...', '6', 8, 1, 3, 7, NULL, NULL, '2026-08-11 23:49:07', '2026-08-28 22:19:18'),
(83, 2, 0, 4, 'The Walking Dead', 'The Walking Dead : Dead City', 'En pause', 'https://image.tmdb.org/t/p/w500/wq3vuQzQgbS83zX3malAFWMsSwX.jpg', 'https://nakastream.tv/player?title=The%20Walking%20Dead%20%3A%20Dead%20City&id=673&poster=/wq3vuQzQgbS83zX3malAFWMsSwX.jpg&type=tv&season={s}&episode={ep}', 'ok', 'Quelques années après les évènements survenus au Commonwealth, Maggie et Negan se rendent dans un Manhattan post-apocalyptique coupé depuis longtemps du continent. La ville en ruine est peuplée de morts et d\'habitants qui ont fait de New York, un ...', '1', 8, 2, 3, 3, NULL, NULL, '2026-08-11 23:50:57', '2026-08-27 18:47:08'),
(84, 2, 0, 4, 'The Walking Dead', 'The Walking Dead : Daryl Dixon', 'En pause', 'https://image.tmdb.org/t/p/w500/sP5QdW9FN18XWcA4ROz3MPAQBTx.jpg', 'https://nakastream.tv/player?title=The%20Walking%20Dead%20%3A%20Daryl%20Dixon&id=672&poster=/sP5QdW9FN18XWcA4ROz3MPAQBTx.jpg&type=tv&season={s}&episode={ep}', 'ok', 'Daryl Dixon se réveille quelque part sur le continent européen et essaie de reconstituer ce qui s\'est passé. Comment est-il arrivé ici ? Comment va-t-il rentrer chez lui ?', '4', 6, 2, 3, 4, NULL, NULL, '2026-08-11 23:53:28', '2026-08-28 22:18:29'),
(85, 2, 0, 4, 'En Pause', 'Under the Dome', 'En pause', 'https://image.tmdb.org/t/p/w500/fwH0ePhd7m3swtCuFeubtR49ZTd.jpg', 'https://nakastream.tv/player?title=Under%20the%20Dome&id=4228&poster=/fwH0ePhd7m3swtCuFeubtR49ZTd.jpg&type=tv&season={s}&episode={ep}', 'ok', 'D\'après le roman du même nom de Stephen King, cette émission suit les habitants de Chester\'s Mill, une petite ville des États-Unis où les événements exceptionnels sont rares. Mais un jour, un dôme invisible apparaît et englobe toute la ville. Les ...', '8', 13, 2, 3, 8, NULL, NULL, '2026-08-11 23:54:39', '2026-08-27 18:47:55'),
(86, 2, 0, 3, 'Saw', 'Saw II', 'À voir', 'https://image.tmdb.org/t/p/w500/tz8Dfep4Vz142fZ9GdRGdhjVrI2.jpg', 'https://nakastream.tv/player?title=Saw%20II&id=3307&poster=/tz8Dfep4Vz142fZ9GdRGdhjVrI2.jpg&type=movie', 'ok', 'Chargé de l’enquête autour d’une mort sanglante, l’Inspecteur Eric Mason est persuadé que le crime est l’œuvre du redoutable Jigsaw, un criminel machiavélique qui impose à ses victimes des choix auxquels personne ne souhaite jamais être confronté....', NULL, NULL, NULL, NULL, 3, NULL, NULL, '2026-08-12 00:03:10', '2026-08-19 18:36:43'),
(87, 2, 0, 3, 'Saw', 'Saw III', 'À voir', 'https://image.tmdb.org/t/p/w500/oT0CHpyQgryaz4z3TAq9Gvtcn2A.jpg', 'https://nakastream.tv/player?title=Saw%20III&id=4151&poster=/aOKaThXYt1cKnIx6lFKl1tVROz2.jpg&type=movie', 'ok', 'Le tueur au puzzle a mystérieusement échappé à ceux qui pensaient le tenir. Pendant que la police se démène pour tenter de remettre la main dessus, le génie criminel a décidé de reprendre son jeu terrifiant avec l’aide de sa protégée, Amanda. Le d...', NULL, NULL, NULL, NULL, 4, NULL, NULL, '2026-08-12 00:04:55', '2026-08-19 18:36:43'),
(88, 2, 0, 3, 'Saw', 'Saw IV', 'À voir', 'https://image.tmdb.org/t/p/w500/4igbMego1x6SpBxGuER3bqTTLkW.jpg', 'https://nakastream.tv/player?title=Saw%20IV&id=6321&poster=/bOmwqSCNnz1isYCc9fc5NMchspf.jpg&type=movie', 'ok', 'Le tueur au puzzle et sa protégée, Amanda, ont disparu, mais la partie continue. Après le meurtre de l’inspectrice Kerry, deux profileurs chevronnés du FBI, les agents Strahm et Perez, viennent aider le détective Hoffman à réunir les pièces du der...', NULL, NULL, NULL, NULL, 5, NULL, NULL, '2026-08-12 00:05:29', '2026-08-19 18:36:43'),
(89, 2, 0, 3, 'Saw', 'Saw V', 'À voir', 'https://image.tmdb.org/t/p/w500/2J1huUvravSdwuCVydu4RXEeHYh.jpg', 'https://nakastream.tv/player?title=Saw%20V&id=3577&poster=/rA8w4g4eg0GcD0P8mZZR11r7r4X.jpg&type=movie', 'ok', 'Il semble qu\'Hoffman soit le seul héritier du pouvoir du tueur au puzzle. Mais lorsque son secret risque d’être découvert, il n’a pas le droit à l’erreur et doit éliminer chaque menace. Les pièges vont se multiplier pour se refermer, inexorablemen...', NULL, NULL, NULL, NULL, 6, NULL, NULL, '2026-08-12 00:06:03', '2026-08-19 18:36:43'),
(90, 2, 0, 3, 'Saw', 'Saw VI', 'À voir', 'https://image.tmdb.org/t/p/w500/4g097vnfnpWjKHTT0DuRKIihArj.jpg', 'https://nakastream.tv/player?title=Saw%20VI&id=3429&poster=/4g097vnfnpWjKHTT0DuRKIihArj.jpg&type=movie', 'ok', 'L’agent spécial Strahm est mort, et le détective Hoffman s’impose alors comme le légataire incontesté de l’héritage de Jigsaw. Cependant, tandis que le FBI se rapproche de plus en plus dangereusement de lui, Hoffman est obligé de commencer un nouv...', NULL, NULL, NULL, NULL, 7, NULL, NULL, '2026-08-12 00:06:56', '2026-08-19 18:36:43'),
(91, 2, 0, 3, 'Saw', 'Saw 3D : Chapitre final', 'À voir', 'https://image.tmdb.org/t/p/w500/lVeg4c1XQMYeXXrXl2259qCDXUw.jpg', 'https://nakastream.tv/player?title=Saw%203D%20%3A%20Chapitre%20final&id=6484&poster=/lVeg4c1XQMYeXXrXl2259qCDXUw.jpg&type=movie', 'ok', 'Alors que la bataille fait rage autour de l’héritage terrifiant du Tueur au puzzle, un groupe de survivants s’associe et fait appel à un autre rescapé, Bobby Dagen, une sorte de gourou. En croyant trouver de l’aide, ils vont vivre le pire. Bobby c...', NULL, NULL, NULL, NULL, 8, NULL, NULL, '2026-08-12 00:07:51', '2026-08-19 18:36:43'),
(92, 2, 0, 3, 'Saw', 'Jigsaw', 'À voir', 'https://image.tmdb.org/t/p/w500/8nJqDxcJSbb72foMUahP9QVrYWm.jpg', 'https://nakastream.tv/player?title=Jigsaw&id=7247&poster=/8nJqDxcJSbb72foMUahP9QVrYWm.jpg&type=movie', 'ok', 'Après une série de meurtres qui ressemblent étrangement à ceux de Jigsaw, le tueur au puzzle, la police se lance à la poursuite d’un homme mort depuis plus de dix ans. Un nouveau jeu vient de commencer… John Kramer est‐il revenu d’entre les morts ...', NULL, NULL, NULL, NULL, 9, NULL, NULL, '2026-08-12 00:08:23', '2026-08-19 18:36:43'),
(93, 2, 0, 3, 'Saw', 'Spirale : L\'Héritage de Saw', 'À voir', 'https://image.tmdb.org/t/p/w500/2QVoPPQ3GrBx4eHUx1X29EGe2B4.jpg', 'https://nakastream.tv/player?title=Spirale%C2%A0%3A%20L%27H%C3%A9ritage%20de%20Saw&id=7899&poster=/2QVoPPQ3GrBx4eHUx1X29EGe2B4.jpg&type=movie', 'ok', 'Travaillant dans l\'ombre d’une légende locale de la police, le lieutenant Ezekiel « Zeke » Banks et son nouveau partenaire enquêtent sur une série de meurtres macabres dont le mode opératoire rappelle étrangement celui d’un tueur en série qui sévi...', NULL, NULL, NULL, NULL, 10, NULL, NULL, '2026-08-12 00:09:18', '2026-08-19 18:36:43'),
(94, 2, 0, 3, 'Saw', 'Saw X', 'À voir', 'https://image.tmdb.org/t/p/w500/yMUhmrRYlNvE2ALpWvC8lNAM3Sa.jpg', 'https://nakastream.tv/player?title=Saw%20X&id=1939&poster=/yMUhmrRYlNvE2ALpWvC8lNAM3Sa.jpg&type=movie', 'ok', 'Dans l\'espoir d\'une guérison miraculeuse, John Kramer se rend au Mexique pour une procédure médicale risquée et expérimentale, pour découvrir que toute l\'opération est une arnaque visant à escroquer les plus vulnérables. Armé d\'un nouvel objectif,...', NULL, NULL, NULL, NULL, 11, NULL, NULL, '2026-08-12 00:10:12', '2026-08-19 18:36:43'),
(95, 2, 0, 3, 'La Planète des singes', 'La Planète des singes : L\'Affrontement', 'À voir', 'https://image.tmdb.org/t/p/w500/ioCKDIwA4iXs8h4pEMTXN7E5LKG.jpg', 'https://nakastream.tv/player?title=La%20Plan%C3%A8te%20des%20singes%20%3A%20L%27Affrontement&id=1054&poster=/ioCKDIwA4iXs8h4pEMTXN7E5LKG.jpg&type=movie', 'ok', 'Une nation de plus en plus nombreuse de singes évolués, dirigée par César, est menacée par un groupe d’humains qui a survécu au virus dévastateur qui s\'est répandu 10 ans plus tôt. Ils parviennent à une trêve fragile, mais de courte durée : les de...', NULL, NULL, NULL, NULL, 0, NULL, NULL, '2026-08-12 00:12:27', '2026-08-28 22:17:37'),
(96, 2, 0, 3, 'La Planète des singes', 'La Planète des singes : Suprématie', 'À voir', 'https://image.tmdb.org/t/p/w500/4lex7Z6pgnkHvc5KYAgKfcdYuPJ.jpg', 'https://nakastream.tv/player?title=La%20Plan%C3%A8te%20des%20singes%20%3A%20Supr%C3%A9matie&id=1056&poster=/4Ar01t6sW1ZZBcbz2R1wqjzIBdr.jpg&type=movie', 'ok', 'César et les Singes sont contraints de mener un combat dont ils ne veulent pas contre une armée d\'Humains dirigée par un Colonel impitoyable. Les Singes connaissent des pertes considérables et César, dans sa quête de vengeance, va devoir lutter co...', NULL, NULL, NULL, NULL, 1, NULL, NULL, '2026-08-12 00:13:07', '2026-08-28 22:17:45'),
(97, 2, 0, 3, 'La Planète des singes', 'La Planète des singes : Le Nouveau Royaume', 'À voir', 'https://image.tmdb.org/t/p/w500/4925wPllJdQmHd1RxbZ62ZekaW3.jpg', 'https://nakastream.tv/player?title=La%20Plan%C3%A8te%20des%20singes%20%3A%20Le%20Nouveau%20Royaume&id=1053&poster=/4925wPllJdQmHd1RxbZ62ZekaW3.jpg&type=movie', 'ok', 'Plusieurs générations après le règne de César, les singes ont définitivement pris le pouvoir. Les humains, quant à eux, ont régressé à l\'état sauvage et vivent en retrait. Alors qu\'un nouveau chef tyrannique construit peu à peu son empire, un jeun...', NULL, NULL, NULL, NULL, 2, NULL, NULL, '2026-08-12 00:13:46', '2026-08-28 22:17:52'),
(98, 2, 0, 4, 'A Voir', 'His Dark Materials : À la croisée des mondes', 'À voir', 'https://image.tmdb.org/t/p/w500/yxkepbA5TFZkQ7ThRjbV08QXRCq.jpg', 'https://nakastream.tv/player?title=His%20Dark%20Materials%20%3A%20%C3%80%20la%20crois%C3%A9e%20des%20mondes&id=7348&poster=/yxkepbA5TFZkQ7ThRjbV08QXRCq.jpg&type=tv&season={s}&episode={ep}', 'ok', 'Courageuse et futée, Lyra se retrouve embarquée dans une folle aventure dans les contrées du Nord, à la recherche de son meilleur ami disparu. Pourquoi cette jeune fille orpheline, élevée dans l\'atmosphère austère et confinée du prestigieux Jordan...', '1', 8, 1, 3, 5, NULL, NULL, '2026-08-12 00:21:46', '2026-08-28 22:19:00'),
(99, 5, 0, 4, NULL, 'Kally\'s Mashup, la voix de la pop', 'À voir', 'https://image.tmdb.org/t/p/w500/axclJ10eoxxpVyZZC7FPq8jA6Gf.jpg', 'https://papadustreami.yachts/cat-series/comedie-s/13375-kallys-mashup-53d/{s}-saison/{ep}-episode.html', 'ok', 'Kally est une jeune prodige de la musique de 13 ans qui cherche l\'équilibre entre sa vie de pianiste et ses occupations d\'adolescente.', '1', NULL, 1, NULL, 3, NULL, '2026-08-17 13:11:12', '2026-08-15 12:49:04', '2026-08-17 13:11:12'),
(100, 5, 0, 3, NULL, 'Le Prince et moi', 'Terminé', 'https://image.tmdb.org/t/p/w500/m0SSHCU6o9lp4HrxIuvIonfth0p.jpg', 'https://nakastream.tv/player?id=8046&title=Le+Prince+et+moi&type=movie&poster=%2Fm0SSHCU6o9lp4HrxIuvIonfth0p.jpg&backdrop=%2Fu70yZonRQy8WOURASeTmxhKWDIT.jpg', 'ok', 'À l\'université du Wisconsin, le prince héritier du Danemark tombe amoureux d\'une fille de fermiers qui étudie en médecine. Désirant l\'épouser pour en faire la future reine de son pays, le jeune prince doit d\'abord la présenter à ses sévères parent...', NULL, NULL, NULL, NULL, 0, NULL, NULL, '2026-08-16 00:05:55', '2026-08-21 14:18:35'),
(101, 5, 0, 3, NULL, 'Cendrillon', 'Terminé', 'https://image.tmdb.org/t/p/w500/xQB77ZHBchFdZkiPCBJGQDd9qzB.jpg', '', 'ok', 'Après la mort de la mère de la jeune Ella, son père, un marchand, se remarie. Ella accueille chaleureusement sa belle‐mère, Lady Tremaine, et ses deux filles Anastasia et Drisella. Mais lorsque le père d’Ella disparaît à son tour, les trois femmes...', NULL, NULL, NULL, NULL, 1, NULL, '2026-08-21 14:02:26', '2026-08-17 13:02:19', '2026-08-21 14:02:26'),
(102, 4, 0, 3, NULL, 'La Planète des singes : Le Nouveau Royaume', 'À voir', 'https://image.tmdb.org/t/p/w500/4925wPllJdQmHd1RxbZ62ZekaW3.jpg', '', 'ok', 'Plusieurs générations après le règne de César, les singes ont définitivement pris le pouvoir. Les humains, quant à eux, ont régressé à l\'état sauvage et vivent en retrait. Alors qu\'un nouveau chef tyrannique construit peu à peu son empire, un jeun...', NULL, NULL, NULL, NULL, 0, NULL, '2026-08-19 17:23:24', '2026-08-19 17:23:09', '2026-08-19 17:23:24'),
(103, 1, 1, 11, 'IA', 'Copilot', 'Aucun', '', '', 'ok', '', NULL, NULL, NULL, NULL, 2, NULL, NULL, '2026-08-19 17:45:26', '2026-08-19 17:46:18'),
(104, 2, 0, 3, 'Bad Boys', 'Bad Boys', 'À voir', 'https://image.tmdb.org/t/p/w500/at4ZF98aNjML2IeauN0dnbm6aJ5.jpg', 'https://nakastream.tv/player?title=Bad%20Boys&id=1922&poster=/at4ZF98aNjML2IeauN0dnbm6aJ5.jpg&type=movie', 'ok', 'Si Mike Lowrey est un séducteur invétéré, héritier d\'une fortune et policier par passion, son collègue et ami Marcus Burnett est un homme rangé, marié et père de famille. Leur amitié ne les empêche pas d\'avoir des méthodes parfaitement différentes...', NULL, NULL, NULL, NULL, 12, NULL, NULL, '2026-08-19 18:34:08', '2026-08-19 18:36:43'),
(105, 2, 0, 3, 'Bad Boys', 'Bad Boys 2', 'À voir', 'https://image.tmdb.org/t/p/w500/vWrJVeFSPprMnhycJShZOicHAPJ.jpg', 'https://nakastream.tv/player?title=Bad%20Boys%202&id=4260&poster=/vWrJVeFSPprMnhycJShZOicHAPJ.jpg&type=movie', 'ok', 'Les policiers Marcus Burnett et Mike Lowrey enquêtent sur Tapia, un ambitieux baron de la drogue décidé à tout pour inonder Miami d\'un nouveau poison et accroître son empire. Au cours de leurs investigations, ils se voient épaulés par Syd, la sœur...', NULL, NULL, NULL, NULL, 13, NULL, NULL, '2026-08-19 18:34:50', '2026-08-19 18:36:43'),
(106, 2, 0, 3, 'Bad Boys', 'Bad Boys for Life', 'À voir', 'https://image.tmdb.org/t/p/w500/xbo43M8kdKK5Ku2oaKDMO9PNyo5.jpg', 'https://nakastream.tv/player?title=Bad%20Boys%20for%20Life&id=4259&poster=/xbo43M8kdKK5Ku2oaKDMO9PNyo5.jpg&type=movie', 'ok', 'Les Bad Boys Mike Lowrey et Marcus Burnett se retrouvent pour résoudre une nouvelle affaire.', NULL, NULL, NULL, NULL, 14, NULL, NULL, '2026-08-19 18:35:15', '2026-08-19 18:36:43'),
(107, 2, 0, 3, 'Bad Boys', 'Bad Boys : Ride or Die', 'À voir', 'https://image.tmdb.org/t/p/w500/zCZJXSDPZKGml4I5zvxNpdx8jra.jpg', 'https://nakastream.tv/player?title=Bad%20Boys%20%3A%20Ride%20or%20Die&id=1853&poster=/zCZJXSDPZKGml4I5zvxNpdx8jra.jpg&type=movie', 'ok', 'Le détective de Miami Mike Lowrey apprend que son ex-supérieur à l\'escouade anti-drogue, le défunt capitaine Howard, aurait reçu des centaines de millions de dollars de la part des cartels mexicains. Avec son coéquipier et ami Marcus Burnett, Mike...', NULL, NULL, NULL, NULL, 15, NULL, NULL, '2026-08-19 18:35:28', '2026-08-19 18:36:43'),
(109, 5, 0, 3, NULL, 'Harry Potter à l\'école des sorciers', 'Terminé', 'https://image.tmdb.org/t/p/w500/fbxQ44VRdM2PVzHSNajUseUteem.jpg', 'https://nakastream.tv/player?id=454&title=Harry+Potter+%C3%A0+l%27%C3%A9cole+des+sorciers&type=movie&poster=%2FfbxQ44VRdM2PVzHSNajUseUteem.jpg&backdrop=%2F1XAC6RPT01UX9EQGy2JVn5c8pgy.jpg', 'ok', 'Orphelin, le jeune Harry Potter peut enfin quitter ses tyranniques oncle et tante Dursley lorsqu\'un curieux messager lui révèle qu\'il est un sorcier. À 11 ans, Harry va enfin pouvoir intégrer la légendaire école de sorcellerie de Poudlard, y trouv...', NULL, NULL, NULL, NULL, 1, NULL, NULL, '2026-08-21 14:10:02', '2026-08-21 16:12:03'),
(110, 5, 0, 3, NULL, 'Harry Potter et la Chambre des secrets', 'Terminé', 'https://image.tmdb.org/t/p/w500/8KpHRokGpiaqEGpjYe0rpywtvUx.jpg', 'https://nakastream.tv/player?title=Harry%20Potter%20et%20la%20Chambre%20des%20secrets&id=456&poster=/8KpHRokGpiaqEGpjYe0rpywtvUx.jpg&type=movie', 'ok', 'Après de très mauvaises vacances passées chez ses odieux oncle et tante et son affreux cousin, Harry rejoint, non sans mal, l\'École des Sorciers où, avec ses amis Ron et Hermione et l\'aide ponctuelle de nouveaux venus, il parvient à élucider le my...', NULL, NULL, NULL, NULL, 2, NULL, NULL, '2026-08-21 14:18:12', '2026-08-21 23:05:54'),
(111, 5, 0, 3, NULL, 'Harry Potter et le Prisonnier d\'Azkaban', 'Terminé', 'https://image.tmdb.org/t/p/w500/t4P2079IyK19njHDP2GwQrKdvzd.jpg', 'https://nakastream.tv/player?title=Harry%20Potter%20et%20le%20Prisonnier%20d%27Azkaban&id=455&poster=/t4P2079IyK19njHDP2GwQrKdvzd.jpg&type=movie', 'ok', 'Sirius Black, un dangereux sorcier criminel, s’échappe de la sombre prison d’Azkaban avec un seul et unique but : retrouver Harry Potter, en troisième année à l’école de Poudlard. Selon la légende, Black aurait jadis livré les parents du jeune sor...', NULL, NULL, NULL, NULL, 3, NULL, NULL, '2026-08-21 14:22:08', '2026-08-22 00:57:39'),
(112, 5, 0, 3, NULL, 'Harry Potter et la Coupe de feu', 'Terminé', 'https://image.tmdb.org/t/p/w500/hBak1pn5pbI4ycAbrgMMn1YI7P1.jpg', 'https://nakastream.tv/player?title=Harry%20Potter%20et%20la%20Coupe%20de%20feu&id=499&poster=/hBak1pn5pbI4ycAbrgMMn1YI7P1.jpg&type=movie', 'ok', 'La quatrième année à l’école de Poudlard est marquée par le « Tournoi des trois sorciers ». Les participants sont choisis par la fameuse « Coupe de feu » qui est à l’origine d’un scandale. Elle sélectionne Harry Potter alors qu’il n’a pas l’âge re...', NULL, NULL, NULL, NULL, 4, NULL, NULL, '2026-08-22 01:01:23', '2026-08-22 03:02:11'),
(113, 5, 0, 3, NULL, 'Harry Potter et l\'Ordre du Phénix', 'Terminé', 'https://image.tmdb.org/t/p/w500/9ZfpCVNx0y8jpColnnfdA1HI4Zb.jpg', 'https://nakastream.tv/player?title=Harry%20Potter%20et%20l%27Ordre%20du%20Ph%C3%A9nix&id=501&poster=/9ZfpCVNx0y8jpColnnfdA1HI4Zb.jpg&type=movie', 'ok', 'Alors qu’il entame sa cinquième année d’étude à Poudlard, Harry Potter découvre qu’une bonne partie de la communauté des sorciers feint d’ignorer sa récente confrontation avec Lord Voldemort, et préfèrent nier cette aveuglante évidence : le Seigne...', NULL, NULL, NULL, NULL, 5, NULL, NULL, '2026-08-22 01:27:07', '2026-08-23 01:19:16'),
(114, 5, 0, 3, NULL, 'Harry Potter et le Prince de sang-mêlé', 'Terminé', 'https://image.tmdb.org/t/p/w500/A4WWOzWUASfUeESXxduQxVmoD7t.jpg', 'https://nakastream.tv/player?title=Harry%20Potter%20et%20le%20Prince%20de%20sang-m%C3%AAl%C3%A9&id=500&poster=/A4WWOzWUASfUeESXxduQxVmoD7t.jpg&type=movie', 'ok', 'Voldemort a renforcé son emprise sur le monde des sorciers aussi bien que sur celui des Moldus, et Poudlard n’est plus un endroit sûr. Harry est d’ailleurs persuadé que le danger rôde à l’intérieur même de l’école mais Dumbledore est plus soucieux...', NULL, NULL, NULL, NULL, 6, NULL, NULL, '2026-08-22 01:28:46', '2026-08-23 19:30:37');
INSERT INTO `item` (`id`, `id_user`, `is_public`, `id_division`, `sous_categorie`, `titre`, `status`, `image`, `lien`, `link_status`, `description`, `episode`, `total_episodes`, `saison`, `total_saisons`, `position`, `date_sortie`, `deleted_at`, `created_at`, `updated_at`) VALUES
(115, 2, 0, 5, NULL, 'Comment l\'ENDURANCE et le FRACTIONNÉ sont complémentaires (+ une théorie sortie du chapeau)', 'À voir', '', 'https://youtu.be/Qg9Vi7yChyo?si=VrnK2DicXzr7qT63', 'ok', '', NULL, NULL, NULL, NULL, 1, NULL, '2026-08-22 17:20:26', '2026-08-22 14:11:54', '2026-08-22 17:20:26'),
(116, 2, 0, 5, NULL, 'The Man from Earth - Film COMPLET', 'À voir', '', 'https://youtu.be/KI9rbgSSaCA?si=IgP5M5Bo6XeBhUx7', 'ok', 'Un scientifique à l\'aube de la retraite dévoile sa véritable identité : il est un immortel âgé de plus de 14 000 ans. Une révélation qui va remettre en cause toutes les croyances de son assistance...', NULL, NULL, NULL, NULL, 0, NULL, NULL, '2026-08-22 16:08:13', '2026-08-22 16:08:17'),
(117, 5, 0, 3, NULL, 'Harry Potter et les Reliques de la Mort - 1ère partie', 'Terminé', 'https://image.tmdb.org/t/p/w500/yJm61MmTMjOmNXxPxdoaIkdqnOm.jpg', 'https://nakastream.tv/player?title=Harry%20Potter%20et%20les%20Reliques%20de%20la%20Mort%C2%A0-%201%C3%A8re%20partie&id=503&poster=/yJm61MmTMjOmNXxPxdoaIkdqnOm.jpg&type=movie', 'ok', 'Le pouvoir de Voldemort s\'étend dangereusement. Le Seigneur des Ténèbres contrôle désormais le Ministère de la Magie et impose sa domination sur Poudlard, semant la peur et la terreur dans le monde des sorciers. Harry, Ron et Hermione, devenus des...', NULL, NULL, NULL, NULL, 7, NULL, NULL, '2026-08-23 19:32:14', '2026-08-23 20:19:57'),
(118, 5, 0, 3, NULL, 'Harry Potter et les Reliques de la Mort - 2ème partie', 'En pause', 'https://image.tmdb.org/t/p/w500/alQOPmKEPHkH4BLMEla1vTNYrUr.jpg', 'https://nakastream.tv/player?title=Harry%20Potter%20et%20les%20Reliques%20de%20la%20Mort%C2%A0-%202%C3%A8me%20partie&id=502&poster=/alQOPmKEPHkH4BLMEla1vTNYrUr.jpg&type=movie', 'ok', 'Le combat entre les puissances du bien et du mal de l’univers des sorciers se transforme en guerre sans merci. L’école Poudlard est désormais sous la coupe du professeur Rogue et des force des ténèbres. Les enjeux sont devenus considérables et per...', NULL, NULL, NULL, NULL, 8, NULL, NULL, '2026-08-23 19:33:13', '2026-08-23 23:23:12'),
(119, 5, 0, 3, NULL, 'The Last Sunrise', 'Terminé', 'https://image.tmdb.org/t/p/w500/myJdCnJEsFsMmjKhKopQ32lkcP3.jpg', 'https://nakastream.tv/player?id=15717&title=The+Last+Sunrise&type=movie&poster=%2FmyJdCnJEsFsMmjKhKopQ32lkcP3.jpg&backdrop=%2F5lB7yPaRhJHQ9dx7AnvPUi0GZDU.jpg', 'ok', 'Inspiré du roman, The Last Sunrise raconte l\'histoire de Ry, une étudiante souffrant d\'une maladie chronique, durant des vacances à Marjoque avec sa mère. Tandis qu\'elle tombe soudainement amoureuse de Julián et qu\'elle commence à vivre l\'instant ...', NULL, NULL, NULL, NULL, 9, NULL, NULL, '2026-08-26 14:15:30', '2026-08-26 15:17:11'),
(120, 2, 0, 3, 'A Voir', 'Jumper', 'À voir', 'https://image.tmdb.org/t/p/w500/l6xYBnfWcAnuMhQtzDlUnNWfuyQ.jpg', 'https://nakastream.tv/player?title=Jumper&id=5082&poster=/l6xYBnfWcAnuMhQtzDlUnNWfuyQ.jpg&type=movie', 'ok', 'Depuis qu\'il a découvert qu\'il pouvait se téléporter n\'importe où sur terre, le monde n\'a plus de limite pour David Rice. Grâce à son pouvoir, il peut déjeuner en Égypte sur la tête du Sphinx, passer la journée à faire du surf en Australie, dîner ...', NULL, NULL, NULL, NULL, 18, NULL, NULL, '2026-08-27 11:05:33', '2026-08-27 11:05:33'),
(121, 2, 0, 1, 'A Voir', 'Le Quotidien du Roi Immortel', 'À voir', 'https://image.tmdb.org/t/p/w500/sDFWmTHD6912EbfdbCNMxPRIecy.jpg', 'https://franime.fr/anime/the-daily-life-of-the-immortal-king?s={s}&ep={ep}&lang=vo&anime_id=43014', 'ok', 'Wang Ling a développé depuis son plus jeune âge d\'incroyables capacités. Cependant, afin de mener une vie ordinaire, ses pouvoirs sont confinés dans un talisman. Malgré cela ses pouvoirs restent puissants et son doux quotidien est menacé lors de s...', '1', 15, 1, 5, 17, NULL, NULL, '2026-08-28 19:27:45', '2026-08-28 19:28:34'),
(122, 2, 0, 1, 'A Voir', 'I Was Reincarnated as the 7th Prince', 'À voir', 'https://image.tmdb.org/t/p/w500/jCIY15zBEiRMifdabq3HjY5kWIM.jpg', 'https://franime.fr/anime/i-was-reincarnated-as-the-7th-prince-so-i-can-take-my-time-perfecting-my-magical-ability?s={s}&ep={ep}&lang=vo&anime_id=46704', 'ok', 'Les qualités les plus appréciées dans l\'étude de la magie sont la lignée, l\'aptitude et l\'effort. Malgré son amour profond pour la magie, un sorcier est né roturier et n’a donc ni le sang, ni les aptitudes nécessaires. Il meurt cependant soudainem...', '1', 12, 2, 2, 18, NULL, NULL, '2026-08-28 19:36:30', '2026-08-28 19:36:30'),
(123, 2, 0, 1, 'En Pause', 'Noble Reincarnation', 'En pause', 'https://image.tmdb.org/t/p/w500/ggxUYlw7a3eVegnXDv8aCDiLccJ.jpg', 'https://franime.fr/anime/kizoku-tensei-megumareta-umare-kara-saikyou-no-chikara-wo-eru?s={s}&ep={ep}&lang=vo&anime_id=49867', 'ok', 'En tant que treizième prince de la famille royale, Noah a toujours mené une vie paisible, loin des intrigues liées à la succession impériale. Mais tout bascule lorsque le prince héritier meurt soudainement, ouvrant la voie à une bataille intestine...', '1', 12, 1, 1, 19, NULL, '2026-08-28 22:02:18', '2026-08-28 22:02:09', '2026-08-28 22:02:18'),
(124, 2, 0, 1, 'En Pause', 'Spy Classroom', 'En pause', 'https://image.tmdb.org/t/p/w500/nxvPDNLSlhdZMGJ1W0Il4ixnH5w.jpg', 'https://franime.fr/anime/spy-classroom?s={s}&ep={ep}&lang=vo&anime_id=45966', 'ok', 'Dans un monde où les pays se sont engagés dans une guerre de l’ombre depuis un conflit militaire dévastateur, Klaus, un brillant espion, crée l’organisation « Lights » : celle-ci a pour objectif de mener à terme des missions qualifiées « d’impossi...', '7', 24, 1, 1, 20, NULL, NULL, '2026-08-28 22:04:58', '2026-08-28 22:04:58'),
(125, 2, 0, 1, 'En Pause', 'Fire Force', 'En pause', 'https://image.tmdb.org/t/p/w500/w39RbZShri0HsN1Vxm2vkNkC7Xo.jpg', 'https://franime.fr/anime/fire-force?s={s}&ep={ep}&lang=vo&anime_id=42068', 'ok', 'Tokyo brûle, et dans toute la ville, des citoyens sont victimes de combustion spontanée. La Fire Force, brigade en charge d’éteindre ce brasier compte une nouvelle recrue dans ses rangs, le jeune Shinra. Au sein de la 8e brigade, il fera bon usage...', '14', 25, 3, 3, 21, NULL, NULL, '2026-08-28 22:06:58', '2026-08-28 22:06:58'),
(126, 2, 0, 1, 'A Voir', 'DanMachi : Sword Oratoria', 'À voir', 'https://image.tmdb.org/t/p/w500/iKNeAEH3cmXCeQRnE09yBk8NDAM.jpg', 'https://franime.fr/anime/sword-oratoria-is-it-wrong-to-try-to-pick-up-girls-in-a-dungeon-on-the-side?s={s}&ep={ep}&lang=vo&anime_id=11902', 'ok', 'La plus puissante femme épéiste mène son équipe durant l\'exploration de cet énorme labyrinthe que l\'on appelle : Donjon. Au 5ème sous-sol du donjon, elle secourt un jeune homme du nom de Bell Cranel qui se fait poursuivre par un minotaure échappé ...', '1', 12, 1, 1, 22, NULL, NULL, '2026-08-28 22:10:03', '2026-08-28 22:10:03'),
(127, 2, 0, 1, 'A Voir', 'Shangri-La Frontier', 'À voir', 'https://image.tmdb.org/t/p/w500/xPxirRd6oTzGGCREKNm1UvW3Y9k.jpg', 'https://franime.fr/anime/shangrila-frontier?s={s}&ep={ep}&lang=vo&anime_id=46241', 'ok', 'Dans un futur proche, les jeux s’affichant sur des écrans sont passés de mode. La technologie VR en immersion domine ce marché, mais parmi la multitude de jeux, un grand nombre sont bien souvent nuls et sans intérêt. Certains ont décidé de s’attaq...', '1', 25, 2, 2, 23, NULL, NULL, '2026-08-28 22:11:34', '2026-08-28 22:11:34'),
(128, 2, 0, 1, 'A Voir', 'The Devil is a Part-Timer!', 'À voir', 'https://image.tmdb.org/t/p/w500/kmpTEICJQweI4RN0OHIxgaetKop.jpg', 'https://franime.fr/anime/the-devil-is-a-parttimer?s={s}&ep={ep}&lang=vo&anime_id=7314', 'ok', 'Le Roi Démon vient d\'être vaincu par le héros lors d\'une guerre sanglante opposant les démons aux humains. Dans un combat final qui tourne en sa défaveur contre le Héros, le Roi Démon s\'enfuit avec son meilleur commandant en ouvrant une porte vers...', '1', 24, 2, 2, 24, NULL, NULL, '2026-08-28 22:13:06', '2026-08-28 22:13:06');

-- --------------------------------------------------------

--
-- Structure de la table `item_revisions`
--

CREATE TABLE `item_revisions` (
  `id` int(10) UNSIGNED NOT NULL,
  `original_item_id` int(10) UNSIGNED NOT NULL,
  `id_user` int(10) UNSIGNED NOT NULL,
  `titre` varchar(100) NOT NULL,
  `sous_categorie` varchar(100) DEFAULT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'Aucun',
  `image` varchar(255) DEFAULT NULL,
  `lien` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `episode` varchar(10) DEFAULT NULL,
  `total_episodes` int(11) DEFAULT NULL,
  `saison` int(11) DEFAULT NULL,
  `total_saisons` int(11) DEFAULT NULL,
  `position` int(11) DEFAULT 0,
  `date_sortie` datetime DEFAULT NULL,
  `revision_status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Structure de la table `migrations`
--

CREATE TABLE `migrations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `version` varchar(255) NOT NULL,
  `class` varchar(255) NOT NULL,
  `group` varchar(255) NOT NULL,
  `namespace` varchar(255) NOT NULL,
  `time` int(11) NOT NULL,
  `batch` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `reports`
--

CREATE TABLE `reports` (
  `id` int(10) UNSIGNED NOT NULL,
  `item_id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED DEFAULT NULL,
  `type` varchar(50) NOT NULL,
  `description` text DEFAULT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'pending',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `settings`
--

CREATE TABLE `settings` (
  `id` int(11) NOT NULL,
  `class` varchar(255) NOT NULL,
  `key` varchar(255) NOT NULL,
  `value` text DEFAULT NULL,
  `type` varchar(31) NOT NULL DEFAULT 'string',
  `context` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `sites_config`
--

CREATE TABLE `sites_config` (
  `id` int(11) NOT NULL,
  `domain` varchar(255) NOT NULL,
  `regex_episode` varchar(255) NOT NULL,
  `indicateurs_page_invalide` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `indicateurs_lecteur` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `is_active` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `sites_config`
--

INSERT INTO `sites_config` (`id`, `domain`, `regex_episode`, `indicateurs_page_invalide`, `indicateurs_lecteur`, `is_active`) VALUES
(1, 'voir-anime.to', '/-(\\d+)-vostfr/i', '[\"Premier EP\", \"Dernier EP\"]', '[\"class=\\\"lecteur\\\"\", \"<iframe\", \"Lecteur\"]', 1),
(2, 'scan-vf.net', '/chapitre-(\\d+)/i', '[\"Liste des chapitres\", \"Manga en cours\"]', '[\"img-responsive\", \"img-fluid\", \"pages_container\"]', 1),
(4, 'franime.fr', '/[?&]ep=(\\d+)/i', '[]', '[\"margin-player\", \"Regarder l&#x27;épisode\"]', 1);

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `username` varchar(30) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `status_message` varchar(255) DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 0,
  `last_active` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`id`, `username`, `status`, `status_message`, `active`, `last_active`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Super Admin', NULL, NULL, 1, '2026-08-23 19:22:40', '2026-04-11 17:01:15', '2026-05-17 12:39:43', NULL),
(2, 'Titiss', NULL, NULL, 1, '2026-08-28 22:19:18', '2026-04-11 17:02:37', '2026-04-11 17:02:38', NULL),
(3, 'Seiko', NULL, NULL, 1, NULL, '2026-04-30 14:13:09', '2026-05-29 22:18:11', NULL),
(4, 'User de test', 'banned', 'Accès révoqué par l\'administration.', 1, '2026-08-19 17:23:26', '2026-05-29 22:30:44', '2026-08-19 17:24:16', NULL),
(5, 'Ambre', NULL, NULL, 1, '2026-08-28 00:38:19', '2026-06-17 20:17:27', '2026-06-25 12:09:08', NULL);

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `audit_logs`
--
ALTER TABLE `audit_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Index pour la table `auth_groups_users`
--
ALTER TABLE `auth_groups_users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `auth_groups_users_user_id_foreign` (`user_id`);

--
-- Index pour la table `auth_identities`
--
ALTER TABLE `auth_identities`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `type_secret` (`type`,`secret`),
  ADD KEY `user_id` (`user_id`);

--
-- Index pour la table `auth_logins`
--
ALTER TABLE `auth_logins`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_type_identifier` (`id_type`,`identifier`),
  ADD KEY `user_id` (`user_id`);

--
-- Index pour la table `auth_permissions_users`
--
ALTER TABLE `auth_permissions_users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `auth_permissions_users_user_id_foreign` (`user_id`);

--
-- Index pour la table `auth_remember_tokens`
--
ALTER TABLE `auth_remember_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `selector` (`selector`),
  ADD KEY `auth_remember_tokens_user_id_foreign` (`user_id`);

--
-- Index pour la table `auth_token_logins`
--
ALTER TABLE `auth_token_logins`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_type_identifier` (`id_type`,`identifier`),
  ADD KEY `user_id` (`user_id`);

--
-- Index pour la table `cron_logs`
--
ALTER TABLE `cron_logs`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `division`
--
ALTER TABLE `division`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_header` (`id_header`);

--
-- Index pour la table `header`
--
ALTER TABLE `header`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `item`
--
ALTER TABLE `item`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_user` (`id_user`,`id_division`),
  ADD KEY `id_division` (`id_division`);

--
-- Index pour la table `item_revisions`
--
ALTER TABLE `item_revisions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `original_item_id` (`original_item_id`),
  ADD KEY `id_user` (`id_user`);

--
-- Index pour la table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `reports`
--
ALTER TABLE `reports`
  ADD PRIMARY KEY (`id`),
  ADD KEY `item_id` (`item_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Index pour la table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `sites_config`
--
ALTER TABLE `sites_config`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `audit_logs`
--
ALTER TABLE `audit_logs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=172;

--
-- AUTO_INCREMENT pour la table `auth_groups_users`
--
ALTER TABLE `auth_groups_users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT pour la table `auth_identities`
--
ALTER TABLE `auth_identities`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT pour la table `auth_logins`
--
ALTER TABLE `auth_logins`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT pour la table `auth_permissions_users`
--
ALTER TABLE `auth_permissions_users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `auth_remember_tokens`
--
ALTER TABLE `auth_remember_tokens`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT pour la table `cron_logs`
--
ALTER TABLE `cron_logs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `division`
--
ALTER TABLE `division`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT pour la table `item`
--
ALTER TABLE `item`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=129;

--
-- AUTO_INCREMENT pour la table `item_revisions`
--
ALTER TABLE `item_revisions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `reports`
--
ALTER TABLE `reports`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `sites_config`
--
ALTER TABLE `sites_config`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT pour la table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `audit_logs`
--
ALTER TABLE `audit_logs`
  ADD CONSTRAINT `audit_logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Contraintes pour la table `division`
--
ALTER TABLE `division`
  ADD CONSTRAINT `division_ibfk_1` FOREIGN KEY (`id_header`) REFERENCES `header` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `item`
--
ALTER TABLE `item`
  ADD CONSTRAINT `item_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `item_ibfk_2` FOREIGN KEY (`id_division`) REFERENCES `division` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `item_revisions`
--
ALTER TABLE `item_revisions`
  ADD CONSTRAINT `item_revisions_ibfk_1` FOREIGN KEY (`original_item_id`) REFERENCES `item` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `item_revisions_ibfk_2` FOREIGN KEY (`id_user`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `reports`
--
ALTER TABLE `reports`
  ADD CONSTRAINT `reports_item_fk` FOREIGN KEY (`item_id`) REFERENCES `item` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `reports_user_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
